package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.BlogPost
import com.example.data.model.Comment
import com.example.data.model.UserRole
import com.example.ui.components.AppNavigationDrawerContent
import com.example.ui.components.BlogAppHeader
import com.example.ui.components.BlogBottomNav
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BlogViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.flow.collectLatest
import coil.Coil
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure optimized Coil image loader
        val imageLoader = ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizePercent(0.02)
                    .build()
            }
            .crossfade(true)
            .respectCacheHeaders(false)
            .build()
        Coil.setImageLoader(imageLoader)

        setContent {
            val viewModel: BlogViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val isDark = uiState.isDarkMode ?: isSystemInDarkTheme()
            val isArabic = uiState.appLanguage == "ar"

            MyApplicationTheme(darkTheme = isDark) {
                // Support RTL for Arabic and LTR for English
                CompositionLocalProvider(LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                    BlogMainApp(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlogMainApp(viewModel: BlogViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    val publishedPosts by viewModel.publishedPosts.collectAsStateWithLifecycle()
    val featuredPosts by viewModel.featuredPosts.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val bookmarkedPosts by viewModel.bookmarkedPosts.collectAsStateWithLifecycle()
    val bookmarkedPostIds by viewModel.bookmarkedPostIds.collectAsStateWithLifecycle()
    val likedPostIds by viewModel.likedPostIds.collectAsStateWithLifecycle()
    val myPosts by viewModel.myPosts.collectAsStateWithLifecycle()

    val allPostsAdmin by viewModel.allPostsAdmin.collectAsStateWithLifecycle()
    val allUsersAdmin by viewModel.allUsersAdmin.collectAsStateWithLifecycle()
    val reportedPostsAdmin by viewModel.reportedPostsAdmin.collectAsStateWithLifecycle()
    val pendingPosts by viewModel.pendingPosts.collectAsStateWithLifecycle()
    val totalComments by viewModel.totalCommentsCount.collectAsStateWithLifecycle()

    val adminWithdrawals by viewModel.adminWithdrawals.collectAsStateWithLifecycle()
    val allPurchases by viewModel.allPurchases.collectAsStateWithLifecycle()
    val allAdMetrics by viewModel.allAdMetrics.collectAsStateWithLifecycle()
    val allAdCampaignsAdmin by viewModel.allAdCampaignsAdmin.collectAsStateWithLifecycle()
    val pendingAdCampaignsAdmin by viewModel.pendingAdCampaignsAdmin.collectAsStateWithLifecycle()
    val userWithdrawals by viewModel.userWithdrawalRequests.collectAsStateWithLifecycle()
    val purchasedArticleIds by viewModel.purchasedPostIds.collectAsStateWithLifecycle()
    val authorSales by viewModel.authorSales.collectAsStateWithLifecycle()
    val authorAdMetrics by viewModel.authorAdMetrics.collectAsStateWithLifecycle()
    val userAdCampaigns by viewModel.userAdCampaigns.collectAsStateWithLifecycle()
    val activeAdCampaigns by viewModel.activeAdCampaigns.collectAsStateWithLifecycle()
    val supportTickets by (if (currentUser?.role == com.example.data.model.UserRole.ADMIN) viewModel.allSupportTicketsAdmin else viewModel.userSupportTickets).collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    // Handle Snackbar messages
    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            coroutineScope.launch {
                snackbarHostState.showSnackbar(msg)
                viewModel.clearSnackbar()
            }
        }
    }

    // Selected Post for Detail View
    var selectedPost by remember { mutableStateOf<BlogPost?>(null) }
    var selectedPostComments by remember { mutableStateOf<List<Comment>>(emptyList()) }

    LaunchedEffect(uiState.selectedPostId) {
        val id = uiState.selectedPostId
        if (id != null) {
            selectedPost = viewModel.repository.getPostById(id)
            viewModel.repository.getCommentsForPost(id).collectLatest {
                selectedPostComments = it
            }
        }
    }

    // Editing Post for Editor View
    var editingPost by remember { mutableStateOf<BlogPost?>(null) }
    LaunchedEffect(uiState.editingPostId) {
        val id = uiState.editingPostId
        editingPost = if (id != null) viewModel.repository.getPostById(id) else null
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppNavigationDrawerContent(
                currentUser = currentUser,
                currentScreen = uiState.currentScreen,
                isDarkMode = uiState.isDarkMode,
                appLanguage = uiState.appLanguage,
                soundEffectsEnabled = uiState.soundEffectsEnabled,
                notificationsEnabled = uiState.notificationsEnabled,
                onNavigate = { viewModel.navigateTo(it) },
                onSetDarkMode = { viewModel.setDarkMode(it) },
                onSetLanguage = { viewModel.setAppLanguage(it) },
                onSetSoundEffects = { viewModel.setSoundEffects(it) },
                onSetNotifications = { viewModel.setNotifications(it) },
                onOpenTerms = { viewModel.setShowTermsDialog(true) },
                onOpenPrivacy = { viewModel.setShowPrivacyDialog(true) },
                onCloseDrawer = {
                    coroutineScope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (uiState.currentScreen != Screen.POST_DETAIL && uiState.currentScreen != Screen.POST_EDITOR) {
                    BlogAppHeader(
                        currentUser = currentUser,
                        searchQuery = uiState.searchQuery,
                        onSearchChange = { viewModel.updateSearchQuery(it) },
                        onOpenAuth = { viewModel.navigateTo(Screen.AUTH) },
                        onOpenAdmin = { viewModel.navigateTo(Screen.ADMIN_PANEL) },
                        onOpenProfile = { viewModel.navigateTo(Screen.PROFILE) },
                        onOpenDrawer = {
                            coroutineScope.launch {
                                if (drawerState.isClosed) drawerState.open() else drawerState.close()
                            }
                        },
                        onOpenAiQA = { viewModel.setAiQADialogOpen(true) }
                    )
                }
            },
            bottomBar = {
                if (uiState.currentScreen != Screen.POST_DETAIL && uiState.currentScreen != Screen.POST_EDITOR) {
                    BlogBottomNav(
                        currentScreen = uiState.currentScreen,
                        currentUser = currentUser,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
            when (uiState.currentScreen) {
                Screen.HOME -> HomeScreen(
                    featuredPosts = featuredPosts,
                    posts = searchResults,
                    categories = categories,
                    selectedCategoryId = uiState.selectedCategoryId,
                    currentUser = currentUser,
                    bookmarkedPostIds = bookmarkedPostIds,
                    likedPostIds = likedPostIds,
                    activeAdCampaigns = activeAdCampaigns,
                    onSelectCategory = { viewModel.selectCategory(it) },
                    onPostClick = { viewModel.openPostDetail(it) },
                    onCreatePostClick = { viewModel.openPostEditor(null) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onLikeToggle = { viewModel.toggleLike(it) },
                    onEditPost = { viewModel.openPostEditor(it) },
                    onDeletePost = { viewModel.deletePost(it) },
                    onToggleFeatured = { id, current -> viewModel.toggleFeatured(id, current) },
                    onAdCampaignClick = { viewModel.recordCampaignClick(it) }
                )

                Screen.CATEGORIES -> CategoriesScreen(
                    categories = categories,
                    onCategoryClick = { catId ->
                        viewModel.selectCategory(catId)
                        viewModel.navigateTo(Screen.HOME)
                    }
                )

                Screen.MY_POSTS -> MyPostsScreen(
                    currentUser = currentUser,
                    myPosts = myPosts,
                    bookmarkedPostIds = bookmarkedPostIds,
                    likedPostIds = likedPostIds,
                    onOpenAuth = { viewModel.navigateTo(Screen.AUTH) },
                    onCreatePost = { viewModel.openPostEditor(null) },
                    onPostClick = { viewModel.openPostDetail(it) },
                    onEditPost = { viewModel.openPostEditor(it) },
                    onDeletePost = { viewModel.deletePost(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onLikeToggle = { viewModel.toggleLike(it) }
                )

                Screen.BOOKMARKS -> BookmarksScreen(
                    currentUser = currentUser,
                    bookmarkedPosts = bookmarkedPosts,
                    bookmarkedPostIds = bookmarkedPostIds,
                    likedPostIds = likedPostIds,
                    onOpenAuth = { viewModel.navigateTo(Screen.AUTH) },
                    onPostClick = { viewModel.openPostDetail(it) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onLikeToggle = { viewModel.toggleLike(it) },
                    onEditPost = { viewModel.openPostEditor(it) },
                    onDeletePost = { viewModel.deletePost(it) }
                )

                Screen.ADMIN_PANEL -> AdminPanelScreen(
                    currentUser = currentUser,
                    allPosts = allPostsAdmin,
                    reportedPosts = reportedPostsAdmin,
                    allUsers = allUsersAdmin,
                    categories = categories,
                    pendingPosts = pendingPosts,
                    totalComments = totalComments,
                    adminWithdrawals = adminWithdrawals,
                    allPurchases = allPurchases,
                    allAdMetrics = allAdMetrics,
                    allAdCampaigns = allAdCampaignsAdmin,
                    pendingAdCampaigns = pendingAdCampaignsAdmin,
                    onToggleUserBan = { viewModel.toggleUserBan(it) },
                    onAddCategory = { name, desc -> viewModel.addCategory(name, desc) },
                    onDeleteCategory = { viewModel.deleteCategory(it) },
                    onToggleFeatured = { id, current -> viewModel.toggleFeatured(id, current) },
                    onUpdatePostStatus = { id, status -> viewModel.updatePostStatus(id, status) },
                    onDeletePost = { viewModel.deletePost(it) },
                    onPostClick = { viewModel.openPostDetail(it) },
                    onProcessWithdrawal = { reqId, uId, amt, approve, reason ->
                        viewModel.processWithdrawalRequest(reqId, uId, amt, approve, reason)
                    },
                    onApproveAdCampaign = { viewModel.approveAdCampaign(it) },
                    onRejectAdCampaign = { viewModel.rejectAdCampaign(it) },
                    onDeleteAdCampaign = { viewModel.deleteAdCampaign(it) },
                    onDismissPostReport = { viewModel.dismissPostReport(it) }
                )

                Screen.PROFILE -> ProfileScreen(
                    currentUser = currentUser,
                    onOpenAdminPanel = { viewModel.navigateTo(Screen.ADMIN_PANEL) },
                    onLogout = { viewModel.logout() },
                    onUpdateProfile = { viewModel.updateProfile(it) },
                    onOpenAuth = { viewModel.navigateTo(Screen.AUTH) },
                    onOpenEarnings = { viewModel.navigateTo(Screen.EARNINGS) },
                    onUpdateUserRole = { viewModel.updateUserRole(it) },
                    onSubscribeAdFree = { viewModel.purchaseAdFreePlan() },
                    onDeleteAccount = { viewModel.deleteAccountAndData() }
                )

                Screen.EARNINGS -> EarningsDashboardScreen(
                    currentUser = currentUser,
                    userWithdrawals = userWithdrawals,
                    authorSales = authorSales,
                    authorAdMetrics = authorAdMetrics,
                    userAdCampaigns = userAdCampaigns,
                    onBackClick = { viewModel.navigateTo(Screen.PROFILE) },
                    onNavigateToSupportTickets = { viewModel.navigateTo(Screen.SUPPORT_TICKETS) },
                    onTopUpWalletViaIap = { amt, pkg -> viewModel.topUpWalletViaIap(amt, pkg) },
                    onVerifyPhone = { phone -> viewModel.verifyPhoneNumber(phone) },
                    onSubmitKyc = { name, doc -> viewModel.submitKycVerification(name, doc) },
                    onSavePayoutSettings = { iban, swift, bank, acc, usdt, net, btc, eType, eAcc ->
                        viewModel.updatePayoutSettings(iban, swift, bank, acc, usdt, net, btc, eType, eAcc)
                    },
                    onSubmitWithdrawal = { amt, method, details ->
                        viewModel.submitWithdrawalRequest(amt, method, details)
                    },
                    onCreateAdCampaign = { title, banner, target, placement, budget, cpc ->
                        viewModel.createAdCampaign(title, banner, target, placement, budget, cpc)
                    },
                    onGenerateAdCopy = { topic, onResult ->
                        viewModel.generateAdCopy(topic, onResult)
                    }
                )

                Screen.SUPPORT_TICKETS -> SupportTicketsScreen(
                    currentUser = currentUser,
                    tickets = supportTickets,
                    onBackClick = { viewModel.navigateTo(Screen.EARNINGS) },
                    onCreateTicket = { subject, category, msg -> viewModel.createSupportTicket(subject, category, msg) },
                    onReplyTicket = { id, reply, status -> viewModel.replyToSupportTicket(id, reply, status) }
                )

                Screen.POST_DETAIL -> PostDetailScreen(
                    post = selectedPost,
                    currentUser = currentUser,
                    comments = selectedPostComments,
                    aiSummary = uiState.aiGeneratedResult,
                    isAiLoading = uiState.isAiLoading,
                    isBookmarked = selectedPost?.let { bookmarkedPostIds.contains(it.id) } ?: false,
                    isLiked = selectedPost?.let { likedPostIds.contains(it.id) } ?: false,
                    isPurchased = selectedPost?.let { purchasedArticleIds.contains(it.id) } ?: false,
                    activeAdCampaigns = activeAdCampaigns,
                    onBackClick = { viewModel.navigateTo(Screen.HOME) },
                    onBookmarkToggle = { viewModel.toggleBookmark(it) },
                    onLikeToggle = { viewModel.toggleLike(it) },
                    onAddComment = { postId, text -> viewModel.addComment(postId, text) },
                    onDeleteComment = { viewModel.deleteComment(it) },
                    onGenerateAiSummary = { prompt -> viewModel.generateWithAi(prompt) },
                    onUnlockClick = { _ ->
                        selectedPost?.let { p ->
                            viewModel.purchaseArticle(p)
                        }
                    },
                    onUnlockViaRewardedAd = {
                        selectedPost?.let { p ->
                            viewModel.unlockArticleViaRewardedAd(p)
                        }
                    },
                    onRecordAdImpression = { postId, authorId, adType ->
                        viewModel.recordAdImpression(postId, authorId, adType)
                    },
                    onAdCampaignClick = { viewModel.recordCampaignClick(it) },
                    onReportPost = { postId, reason -> viewModel.reportContent(postId, reason) },
                    onDeletePost = { viewModel.deletePost(it) }
                )

                Screen.POST_EDITOR -> PostEditorScreen(
                    editingPost = editingPost,
                    categories = categories,
                    aiGeneratedResult = uiState.aiGeneratedResult,
                    isAiLoading = uiState.isAiLoading,
                    onBackClick = { viewModel.navigateTo(Screen.MY_POSTS) },
                    onSavePost = { title, content, summary, catId, catName, cover, tags, asDraft, isPaid, price ->
                        viewModel.savePost(title, content, summary, catId, catName, cover, tags, asDraft, isPaid, price)
                    },
                    onGenerateWithAi = { prompt -> viewModel.generateWithAi(prompt) }
                )

                Screen.AUTH -> AuthScreen(
                    isLoginTab = uiState.isLoginTab,
                    emailInput = uiState.authEmail,
                    passwordInput = uiState.authPass,
                    nameInput = uiState.authName,
                    bioInput = uiState.authBio,
                    selectedRole = uiState.authRole,
                    errorMessage = uiState.authErrorMessage,
                    onSetTab = { viewModel.setAuthTab(it) },
                    onUpdateFields = { email, pass, name, bio, role -> viewModel.updateAuthFields(email, pass, name, bio, role) },
                    onSubmitAuth = { viewModel.submitAuth() },
                    onLoginAsSuperAdmin = { viewModel.loginAsSuperAdmin() },
                    onLoginAsGooglePlayReviewer = { viewModel.loginAsGooglePlayReviewer() }
                )
            }
        }
    }

    // Platform Q&A Assistant Dialog
    if (uiState.showAiQADialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setAiQADialogOpen(false) },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text("مساعد مدونتي الذكي (Gemini)", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "اسأل المساعد الذكي عن أي موضوع وسيقوم بالإجابة وتوجيهك لأفضل المقالات المتاحة في المنصة:",
                        style = MaterialTheme.typography.bodySmall
                    )

                    OutlinedTextField(
                        value = uiState.aiQAPrompt,
                        onValueChange = { viewModel.updateAiQAPrompt(it) },
                        placeholder = { Text("مثال: ما هي أفضل مقالات ريادة الأعمال أو التكنولوجيا؟") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = { viewModel.askPlatformAiQA(uiState.aiQAPrompt) },
                        enabled = !uiState.isAiQALoading && uiState.aiQAPrompt.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (uiState.isAiQALoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري البحث والإجابة...")
                        } else {
                            Text("إرسال السؤال")
                        }
                    }

                    if (uiState.aiQAResponse.isNotBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    "إجابة المساعد الذكي:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    uiState.aiQAResponse,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.setAiQADialogOpen(false) }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Terms and Conditions Dialog
    if (uiState.showTermsDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowTermsDialog(false) },
            icon = {
                Icon(
                    imageVector = Icons.Outlined.Gavel,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "الشروط والأحكام وسياسة النشر",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "1. شروط النشر وحقوق الملكية:\n" +
                                "يلتزم الكاتب بنشر مقالات أصلية غير منسوخة. تُنشر مقالات الكُتاب مباشرة على المنصة وتخضع للرقابة اللاحقة.\n\n" +
                                "2. صلاحيات المشرف العام (ADMIN):\n" +
                                "يحق لإدارة المنصة والمشرف العام إزالة أو حذف أي مقال مخالف للآداب العامة أو حقوق الملكية فور الإبلاغ عنه دون سابق إنذار.\n\n" +
                                "3. إعلانات المعلنين والحملات الممولة:\n" +
                                "تخضع جميع الحملات الإعلانية الممولة لمراجعة المشرف العام والموافقة عليها قبل التفعيل.\n\n" +
                                "4. الأرباح والسحوبات:\n" +
                                "تتم معالجة طلبات سحب الأرباح وفق القنوات المعتمدة بعد استيفاء الحد الأدنى للرصيد والتحقق من الهوية.",
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.setShowTermsDialog(false) }) {
                    Text("موافق ومتابعة")
                }
            }
        )
    }

    // Privacy Policy Dialog
    if (uiState.showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowPrivacyDialog(false) },
            icon = {
                Icon(
                    imageVector = Icons.Outlined.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "سياسة الخصوصية وأمان البيانات",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "• خصوصية الحساب والبيانات الشخصية:\n" +
                                "نحن نحترم خصوصية مستخدمينا. لا نقوم بمشاركة بريدك الإلكتروني أو بياناتك البنكية مع أي طرف ثالث.\n\n" +
                                "• أمان المحفظة والمعاملات:\n" +
                                "يتم تشفير جميع بيانات الدفع وعناوين المحافظ الرقمية (USDT / BTC) محلياً وبأعلى معايير الأمان المتبعة.\n\n" +
                                "• التخزين المحلي:\n" +
                                "تُحفظ المقالات والتفضيلات محلياً لضمان تجربة تصفح سريعة وآمنة حتى في وضع عدم الاتصال.",
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 20.sp
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.setShowPrivacyDialog(false) }) {
                    Text("إغلاق")
                }
            }
        )
    }
}
}
