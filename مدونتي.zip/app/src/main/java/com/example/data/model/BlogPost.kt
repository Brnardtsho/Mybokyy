package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PostStatus {
    PUBLISHED,        // منشور
    DRAFT,            // مسودة
    PENDING_APPROVAL, // بانتظار موافقة المشرف
    REJECTED          // مرفوض
}

@Entity(tableName = "blog_posts")
data class BlogPost(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val summary: String = "",
    val authorId: Long,
    val authorName: String,
    val authorAvatarUrl: String = "",
    val categoryId: Long,
    val categoryName: String,
    val coverImageUrl: String = "",
    val tags: String = "", // Comma-separated tags
    val status: PostStatus = PostStatus.PUBLISHED,
    val isFeatured: Boolean = false, // المميزة في الصفحة الرئيسية (بصلاحية المشرف)
    val viewsCount: Int = 0,
    val likesCount: Int = 0,
    val isPaid: Boolean = false, // مقال مدفوع
    val priceAmount: Double = 0.0, // سعر المقال
    val currency: String = "USD", // العملة USD/USDT
    val isReported: Boolean = false, // تم الإبلاغ عنه من المستخدمين
    val reportReason: String = "", // سبب البلاغ
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
