package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ad_metrics")
data class AdMetric(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val postId: Long,
    val authorId: Long,
    val adType: String, // HEADER, FOOTER, FEED_NATIVE, IN_ARTICLE, REWARDED_VIDEO
    val adProvider: String = "Google AdSense / AdMob",
    val ecpm: Double = 2.50, // Real-time dynamic eCPM ($)
    val impressions: Int = 1,
    val estimatedEarnings: Double = 0.0025,
    val estimatedRevenue: Double = 0.0025,
    val authorShare: Double = 0.000625, // 25% للكاتب
    val platformShare: Double = 0.001875, // 75% لمالك المنصة Admin
    val isHoldActive: Boolean = true, // فترة حجز 30 يوماً
    val holdReleaseDate: Long = System.currentTimeMillis() + (30L * 24L * 60L * 60L * 1000L),
    val createdAt: Long = System.currentTimeMillis()
)
