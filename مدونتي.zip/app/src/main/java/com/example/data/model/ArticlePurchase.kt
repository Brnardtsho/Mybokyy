package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "article_purchases")
data class ArticlePurchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val buyerId: Long,
    val buyerName: String = "",
    val postId: Long,
    val postTitle: String = "",
    val authorId: Long,
    val amount: Double,
    val priceAmount: Double = amount,
    val currency: String = "$",
    val googlePlayFee: Double = amount * 0.15, // 15% متجر Google Play
    val platformShare: Double = amount * 0.20, // 20% عمولة المنصة
    val authorShare: Double = amount * 0.65,   // 65% صافي الكاتب المباشر
    val purchaseMethod: String = "BALANCE",
    val purchasedAt: Long = System.currentTimeMillis()
)
