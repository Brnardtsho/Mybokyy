package com.example.data.repository

import com.example.data.dao.BlogDao
import com.example.data.db.BlogDatabase
import com.example.data.model.*
import com.example.data.service.GeminiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BlogRepository(
    private val dao: BlogDao,
    private val geminiService: GeminiService = GeminiService()
) {

    // Current Logged-In User
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (dao.getUsersCount() == 0) {
                    BlogDatabase.populateInitialData(dao)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun login(email: String, password: String): Result<User> {
        val user = dao.getUserByEmail(email.trim().lowercase())
        return if (user != null && user.passwordHash == password) {
            if (user.status == UserStatus.SUSPENDED) {
                Result.failure(Exception("هذا الحساب محظور من قبل المشرف العام."))
            } else {
                _currentUser.value = user
                Result.success(user)
            }
        } else {
            Result.failure(Exception("البريد الإلكتروني أو كلمة المرور غير صحيحة"))
        }
    }

    suspend fun register(
        email: String,
        password: String,
        displayName: String,
        bio: String,
        role: UserRole = UserRole.AUTHOR
    ): Result<User> {
        val existing = dao.getUserByEmail(email.trim().lowercase())
        if (existing != null) {
            return Result.failure(Exception("البريد الإلكتروني مستخدم بالفعل."))
        }

        val newUser = User(
            email = email.trim().lowercase(),
            passwordHash = password,
            displayName = displayName.ifBlank { "كاتب جديد" },
            bio = bio,
            avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
            role = role,
            status = UserStatus.ACTIVE
        )

        val id = dao.insertUser(newUser)
        val created = newUser.copy(id = id)
        _currentUser.value = created
        return Result.success(created)
    }

    suspend fun logout() {
        _currentUser.value = null
    }

    // Quick switch to Super Admin (Owner) for instant testing & supervision
    suspend fun loginAsSuperAdmin() {
        var admin = dao.getUserByEmail("admin@blog.com")
        if (admin == null) {
            val superAdmin = User(
                email = "admin@blog.com",
                passwordHash = "admin123",
                displayName = "أحمد المشرف العام (مالك التطبيق)",
                bio = "المؤسس والمشرف العام بجميع الصلاحيات الإشرافية.",
                role = UserRole.ADMIN,
                status = UserStatus.ACTIVE
            )
            val id = dao.insertUser(superAdmin)
            admin = superAdmin.copy(id = id)
        }
        _currentUser.value = admin
    }

    // Quick Login for Google Play Store Reviewers & Closed Testers (Demo Account)
    suspend fun loginAsGooglePlayReviewer() {
        var reviewer = dao.getUserByEmail("googleplay.reviewer@example.com")
        if (reviewer == null) {
            val playReviewer = User(
                email = "googleplay.reviewer@example.com",
                passwordHash = "googleplay123",
                displayName = "Google Play Reviewer (Demo Account)",
                bio = "حساب مراجع Google Play مسبق التوثيق والإعداد لاختبار عمليات الشراء (IAP)، الإعلانات المكافأة، وتذاكر الدعم وسحب الأرباح.",
                avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
                role = UserRole.AUTHOR,
                status = UserStatus.ACTIVE,
                balance = 150.00,
                totalEarnedFromSales = 240.00,
                totalEarnedFromAds = 95.00,
                isPhoneVerified = true,
                phoneNumber = "+1 800 555 0199",
                isKycVerified = true,
                kycFullName = "Google Play Reviewer",
                kycDocumentId = "GOOG-REV-88992",
                bankIban = "US8937000001234567890",
                bankSwift = "BOFAUS3N",
                bankName = "Bank of America",
                bankAccountName = "Google Play Reviewer",
                cryptoUsdtAddress = "0x889920112233445566778899AABBCCDDEEFF0011",
                cryptoNetwork = "ERC20"
            )
            val id = dao.insertUser(playReviewer)
            reviewer = playReviewer.copy(id = id)
        }
        _currentUser.value = reviewer
    }

    suspend fun updateProfile(updatedUser: User) {
        dao.updateUser(updatedUser)
        if (_currentUser.value?.id == updatedUser.id) {
            _currentUser.value = updatedUser
        }
    }

    // --- Posts ---
    val publishedPosts: Flow<List<BlogPost>> = dao.getPublishedPosts()
    val featuredPosts: Flow<List<BlogPost>> = dao.getFeaturedPosts()
    val allCategories: Flow<List<Category>> = dao.getAllCategories()
    val allUsersAdmin: Flow<List<User>> = dao.getAllUsers()
    val allPostsAdmin: Flow<List<BlogPost>> = dao.getAllPostsAdmin()
    val pendingApprovalPosts: Flow<List<BlogPost>> = dao.getPendingApprovalPosts()
    val totalCommentsCount: Flow<Int> = dao.getTotalCommentsCount()

    fun getPostsByAuthor(authorId: Long): Flow<List<BlogPost>> = dao.getPostsByAuthor(authorId)
    fun getPostsByCategory(categoryId: Long): Flow<List<BlogPost>> = dao.getPostsByCategory(categoryId)
    fun searchPosts(query: String): Flow<List<BlogPost>> = dao.searchPosts(query)
    fun getBookmarkedPosts(userId: Long): Flow<List<BlogPost>> = dao.getBookmarkedPosts(userId)
    fun getBookmarkedPostIds(userId: Long): Flow<List<Long>> = dao.getBookmarkedPostIds(userId)
    fun getLikedPostIds(userId: Long): Flow<List<Long>> = dao.getLikedPostIds(userId)

    suspend fun getPostById(postId: Long): BlogPost? {
        val post = dao.getPostById(postId)
        if (post != null) {
            dao.incrementViews(postId)
        }
        return post
    }

    fun observePost(postId: Long): Flow<BlogPost?> = dao.observePostById(postId)

    suspend fun savePost(post: BlogPost): Long {
        return if (post.id == 0L) {
            dao.insertPost(post)
        } else {
            dao.updatePost(post.copy(updatedAt = System.currentTimeMillis()))
            post.id
        }
    }

    suspend fun deletePost(postId: Long) {
        dao.deletePost(postId)
    }

    // Admin Supervisor Commands
    suspend fun setFeaturedPost(postId: Long, isFeatured: Boolean) {
        val post = dao.getPostById(postId) ?: return
        dao.updatePost(post.copy(isFeatured = isFeatured))
    }

    suspend fun updatePostStatus(postId: Long, newStatus: PostStatus) {
        val post = dao.getPostById(postId) ?: return
        dao.updatePost(post.copy(status = newStatus))
    }

    suspend fun toggleUserBanStatus(user: User) {
        val newStatus = if (user.status == UserStatus.ACTIVE) UserStatus.SUSPENDED else UserStatus.ACTIVE
        val updated = user.copy(status = newStatus)
        dao.updateUser(updated)
    }

    suspend fun changeUserRole(user: User, newRole: UserRole) {
        val updated = user.copy(role = newRole)
        dao.updateUser(updated)
    }

    // --- Categories Management ---
    suspend fun addCategory(name: String, iconName: String, description: String) {
        dao.insertCategory(Category(name = name, iconName = iconName, description = description))
    }

    suspend fun deleteCategory(categoryId: Long) {
        dao.deleteCategory(categoryId)
    }

    // --- Comments ---
    fun getCommentsForPost(postId: Long): Flow<List<Comment>> = dao.getCommentsForPost(postId)

    suspend fun addComment(postId: Long, user: User, content: String) {
        val comment = Comment(
            postId = postId,
            userId = user.id,
            userName = user.displayName,
            userAvatarUrl = user.avatarUrl,
            content = content
        )
        dao.insertComment(comment)
    }

    suspend fun deleteComment(commentId: Long) {
        dao.deleteComment(commentId)
    }

    // --- Bookmarks & Likes ---
    suspend fun toggleBookmark(userId: Long, postId: Long): Boolean {
        val isBookmarked = dao.isBookmarked(userId, postId)
        if (isBookmarked) {
            dao.removeBookmark(userId, postId)
            return false
        } else {
            dao.addBookmark(Bookmark(userId, postId))
            return true
        }
    }

    suspend fun isBookmarked(userId: Long, postId: Long): Boolean {
        return dao.isBookmarked(userId, postId)
    }

    suspend fun toggleLike(userId: Long, postId: Long): Boolean {
        val isLiked = dao.isLiked(userId, postId)
        if (isLiked) {
            dao.removeLike(userId, postId)
        } else {
            dao.addLike(Like(userId, postId))
        }
        val count = dao.getLikesCount(postId)
        dao.updateLikesCount(postId, count)
        return !isLiked
    }

    // --- Monetization, Paywall & Ad Revenue Share ---
    fun getPurchasedPostIds(userId: Long): Flow<List<Long>> = dao.getPurchasedPostIds(userId)

    suspend fun isArticlePurchased(userId: Long, postId: Long): Boolean {
        return dao.isArticlePurchased(userId, postId)
    }

    suspend fun purchaseArticle(buyer: User, post: BlogPost): Result<String> {
        if (!post.isPaid || post.priceAmount <= 0) {
            return Result.failure(Exception("هذا المقال مجاني بالفعل"))
        }

        val alreadyPurchased = dao.isArticlePurchased(buyer.id, post.id)
        if (alreadyPurchased) {
            return Result.success("المقال مفتوح في حسابك بالفعل")
        }

        val totalAmount = post.priceAmount
        val googlePlayFee = totalAmount * 0.15 // 15% متجر Google Play
        val platformShare = totalAmount * 0.20 // 20% عمولة المنصة لمالك التطبيق
        val authorShare = totalAmount * 0.65   // 65% صافي الكاتب المباشر

        // سجل عملية الشراء
        val purchase = ArticlePurchase(
            buyerId = buyer.id,
            postId = post.id,
            authorId = post.authorId,
            postTitle = post.title,
            amount = totalAmount,
            priceAmount = totalAmount,
            googlePlayFee = googlePlayFee,
            platformShare = platformShare,
            authorShare = authorShare,
            purchaseMethod = "IN_APP_PURCHASE"
        )
        dao.insertPurchase(purchase)

        // تحويل حصة الكاتب الصافية (65%) مباشرة لرصيده المتاح للسحب
        dao.creditAuthorArticleSale(post.authorId, authorShare)

        // تحديث المستمر لجلسة الكاتب إذا كان هو المستخدم الحالي
        _currentUser.value?.let { currentUser ->
            if (currentUser.id == post.authorId) {
                val updatedAuthor = dao.getUserById(post.authorId)
                if (updatedAuthor != null) _currentUser.value = updatedAuthor
            }
        }

        return Result.success("تم شراء المقال بنجاح! يمكنك الآن قراءة المقال كاملاً.")
    }

    suspend fun recordAdImpression(postId: Long, authorId: Long, adType: String) {
        // حساب العائد الفعلي Real-time eCPM بناءً على نوع الإعلان
        val ecpm = when (adType) {
            "REWARDED_VIDEO" -> 16.00 // إعلان فيديو مكافأة eCPM = $16.00 ($0.016 للظهور)
            "IN_ARTICLE" -> 3.50     // إعلان داخل المقال eCPM = $3.50 ($0.0035 للظهور)
            "HEADER" -> 2.20         // بنر علوي eCPM = $2.20 ($0.0022 للظهور)
            "FEED_NATIVE" -> 2.80    // إعلان مدمج بالقائمة eCPM = $2.80 ($0.0028 للظهور)
            else -> 2.00             // إعلان قياسي eCPM = $2.00 ($0.0020 للظهور)
        }

        val grossRevenue = ecpm / 1000.0
        val authorShare = grossRevenue * 0.25   // 25% للكاتب
        val platformShare = grossRevenue * 0.75 // 75% لمالك المنصة Admin

        val metric = AdMetric(
            postId = postId,
            authorId = authorId,
            adType = adType,
            ecpm = ecpm,
            estimatedEarnings = grossRevenue,
            estimatedRevenue = grossRevenue,
            authorShare = authorShare,
            platformShare = platformShare,
            isHoldActive = true, // فترة حجز 30 يوماً
            holdReleaseDate = System.currentTimeMillis() + (30L * 24L * 60L * 60L * 1000L)
        )
        dao.insertAdMetric(metric)

        // قيد الأرباح في رصيد الحجز الإعلاني للكاتب (30 يوم حجز للأرباح الإعلانية)
        dao.creditAuthorAdHoldEarnings(authorId, authorShare)

        // تحديث حالة المستخدم الحالي إذا كان هو الكاتب
        _currentUser.value?.let { current ->
            if (current.id == authorId) {
                val fresh = dao.getUserById(authorId)
                if (fresh != null) _currentUser.value = fresh
            }
        }
    }

    // --- Payout & Withdrawal System ---
    fun getUserWithdrawalRequests(userId: Long): Flow<List<WithdrawalRequest>> = dao.getUserWithdrawalRequests(userId)
    fun getAllWithdrawalRequestsAdmin(): Flow<List<WithdrawalRequest>> = dao.getAllWithdrawalRequestsAdmin()

    fun calculateWithdrawalFee(method: PayoutMethod): Double = when (method) {
        PayoutMethod.BANK -> 5.00      // 5.00$ رسوم معالجة وتحويل بنكي دولي (Swift/IBAN)
        PayoutMethod.USDT -> 1.50      // 1.50$ رسوم شبكة Tron TRC20 / BEP20
        PayoutMethod.BTC -> 3.00       // 3.00$ رسوم شبكة البيتكوين وتأكيد التعدين
        PayoutMethod.E_WALLET -> 0.75  // 0.75$ رسوم بوابة المحافظ الإلكترونية
    }

    suspend fun submitWithdrawalRequest(
        user: User,
        amount: Double,
        method: PayoutMethod,
        details: String
    ): Result<String> {
        if (amount < 50.0) {
            return Result.failure(Exception("الحد الأدنى لطلب السحب هو 50 دولار / USDT لحماية المنصة وتغطية رسوم التحويل."))
        }

        // إنعاش بيانات المستخدم لتأكيد الرصيد المتاح للسحب
        val freshUser = dao.getUserById(user.id) ?: user

        if (!freshUser.isPhoneVerified || !freshUser.isKycVerified || freshUser.isFraudFlagged) {
            return Result.failure(Exception("يلزم إكمال توثيق الهاتف والتحقق المالي (KYC) قبل طلب السحب."))
        }

        if (freshUser.balance < amount) {
            return Result.failure(Exception("رصيدك المتاح للسحب (${String.format("%.2f", freshUser.balance)} $) غير كافٍ لسحب مبلغ $amount $"))
        }

        val fee = calculateWithdrawalFee(method)
        val netAmount = amount - fee
        if (netAmount <= 0.0) {
            return Result.failure(Exception("المبلغ المطلوب لا يغطي رسوم التحويل والمعالجة ($fee $)"))
        }

        // الخصم الفعلي للرصيد المتاح
        val rowsDeducted = dao.deductUserBalance(user.id, amount)
        if (rowsDeducted == 0) {
            return Result.failure(Exception("فشل خصم الرصيد. الرجاء المحاولة لاحقاً."))
        }

        val request = WithdrawalRequest(
            userId = user.id,
            userName = user.displayName,
            userEmail = user.email,
            amount = amount,
            fee = fee,
            netAmount = netAmount,
            payoutMethod = method,
            accountDetails = details,
            status = WithdrawalStatus.PENDING
        )
        dao.insertWithdrawalRequest(request)

        // إحياء كائن المستخدم في الجلسة بالرصيد المخصوم
        val updatedUser = dao.getUserById(user.id)
        if (updatedUser != null) {
            _currentUser.value = updatedUser
        }

        return Result.success("تم إرسال طلب السحب بمبلغ $amount $ (الصافي المستلم: ${String.format("%.2f", netAmount)} $ بعد خصم رسوم $fee $) بنجاح وهو قيد المراجعة.")
    }

    suspend fun processWithdrawalRequest(requestId: Long, userId: Long, amount: Double, approve: Boolean, reason: String = "") {
        if (approve) {
            dao.updateWithdrawalStatus(requestId, WithdrawalStatus.APPROVED, reason = "تم التحويل بنجاح")
        } else {
            // تحويل مرفوض -> استرجاع وإعادة الرصيد للحساب
            dao.updateWithdrawalStatus(requestId, WithdrawalStatus.REJECTED, reason = reason)
            dao.refundUserBalance(userId, amount)
        }

        // تحديث المستخدم المتأثر إن وجد في الجلسة الحالية
        _currentUser.value?.let { current ->
            if (current.id == userId) {
                val fresh = dao.getUserById(userId)
                if (fresh != null) _currentUser.value = fresh
            }
        }
    }

    suspend fun updatePayoutSettings(
        userId: Long,
        iban: String,
        swift: String,
        bankName: String,
        accountName: String,
        usdtAddress: String,
        network: String,
        btcAddress: String,
        eWalletType: String = "",
        eWalletAccount: String = ""
    ) {
        dao.updatePayoutSettings(userId, iban, swift, bankName, accountName, usdtAddress, network, btcAddress, eWalletType, eWalletAccount)
        val fresh = dao.getUserById(userId)
        if (fresh != null && _currentUser.value?.id == userId) {
            _currentUser.value = fresh
        }
    }

    // --- Ad-Free Experience Plan (خطة التصفح بدون إعلانات للقارئ) ---
    suspend fun purchaseAdFreePlan(userId: Long, useWallet: Boolean): Result<String> {
        val user = dao.getUserById(userId) ?: return Result.failure(Exception("المستخدم غير موجود"))
        val planCost = 4.99 // $4.99 لمدة 30 يوم
        val durationMillis = 30L * 24L * 60L * 60L * 1000L // 30 days

        if (useWallet) {
            if (user.balance < planCost) {
                return Result.failure(Exception("رصيد محفظتك (${String.format("%.2f", user.balance)}$) غير كافٍ للاشتراك بخطة إزالة الإعلانات ($4.99)"))
            }
            val deducted = dao.deductUserBalance(userId, planCost)
            if (deducted == 0) {
                return Result.failure(Exception("فشل خصم الرصيد. يرجى المحاولة لاحقاً."))
            }
        }

        val expiresAt = System.currentTimeMillis() + durationMillis
        dao.updateUserAdFreePlan(userId, true, expiresAt)

        val fresh = dao.getUserById(userId)
        if (fresh != null && _currentUser.value?.id == userId) {
            _currentUser.value = fresh
        }

        return Result.success("تم تفعيل اشتراك التصفح بدون إعلانات بنجاح لمدة 30 يوماً! استمتع بتجربة قراءة نقية.")
    }

    // --- Google Play IAP Balance TopUp ---
    suspend fun topUpUserWallet(userId: Long, amount: Double) {
        dao.topUpUserWallet(userId, amount)
        val fresh = dao.getUserById(userId)
        if (fresh != null && _currentUser.value?.id == userId) {
            _currentUser.value = fresh
        }
    }

    // --- Phone Verification, KYC & Anti-Fraud ---
    suspend fun updateUserPhone(userId: Long, phone: String, verified: Boolean) {
        dao.updateUserPhone(userId, phone, verified)
        val fresh = dao.getUserById(userId)
        if (fresh != null && _currentUser.value?.id == userId) {
            _currentUser.value = fresh
        }
    }

    suspend fun updateUserKyc(userId: Long, fullName: String, documentId: String, verified: Boolean) {
        dao.updateUserKyc(userId, fullName, documentId, verified)
        val fresh = dao.getUserById(userId)
        if (fresh != null && _currentUser.value?.id == userId) {
            _currentUser.value = fresh
        }
    }

    suspend fun flagUserFraud(userId: Long, isFlagged: Boolean, reason: String) {
        val newStatus = if (isFlagged) UserStatus.SUSPENDED else UserStatus.ACTIVE
        dao.flagUserFraud(userId, isFlagged, reason, newStatus)
        if (_currentUser.value?.id == userId) {
            val fresh = dao.getUserById(userId)
            if (fresh != null) _currentUser.value = fresh
        }
    }

    // --- Rewarded Video Ad Unlock ---
    suspend fun unlockArticleViaRewardedAd(user: User, post: BlogPost): Boolean {
        // Record purchase/unlock via Rewarded Ad
        val purchase = ArticlePurchase(
            postId = post.id,
            postTitle = post.title,
            buyerId = user.id,
            buyerName = user.displayName,
            authorId = post.authorId,
            amount = post.priceAmount,
            priceAmount = post.priceAmount,
            currency = post.currency,
            authorShare = post.priceAmount * 0.80,
            platformShare = post.priceAmount * 0.20,
            purchaseMethod = "REWARDED_VIDEO_AD"
        )
        dao.insertPurchase(purchase)

        // Credit author with 80% share
        val authorShare = post.priceAmount * 0.80
        dao.updateUserEarnings(post.authorId, authorShare, salesAmount = authorShare, adAmount = 0.0)

        // Record Ad Metric for rewarded video
        val adMetric = AdMetric(
            postId = post.id,
            authorId = post.authorId,
            adType = "REWARDED_VIDEO",
            ecpm = 12.0,
            impressions = 1,
            estimatedEarnings = post.priceAmount * 0.80,
            authorShare = post.priceAmount * 0.80,
            platformShare = post.priceAmount * 0.20
        )
        dao.insertAdMetric(adMetric)
        return true
    }

    // --- Support Tickets ---
    suspend fun createSupportTicket(ticket: SupportTicket): Long {
        return dao.insertSupportTicket(ticket)
    }

    fun getUserSupportTickets(userId: Long): Flow<List<SupportTicket>> = dao.getUserTickets(userId)
    fun getAllSupportTicketsAdmin(): Flow<List<SupportTicket>> = dao.getAllTicketsAdmin()

    suspend fun replyToSupportTicket(ticketId: Long, reply: String, status: TicketStatus) {
        dao.updateTicketReply(ticketId, reply, status)
    }

    fun getAuthorArticleSales(authorId: Long): Flow<List<ArticlePurchase>> = dao.getAuthorArticleSales(authorId)
    fun getUserAdMetrics(authorId: Long): Flow<List<AdMetric>> = dao.getUserAdMetrics(authorId)
    fun getAllArticlePurchasesAdmin(): Flow<List<ArticlePurchase>> = dao.getAllArticlePurchasesAdmin()
    fun getAllAdMetricsAdmin(): Flow<List<AdMetric>> = dao.getAllAdMetricsAdmin()


    // --- User Role Switch & Account Deletion ---
    suspend fun updateUserRole(userId: Long, newRole: UserRole) {
        val user = dao.getUserById(userId)
        if (user != null) {
            val updated = user.copy(role = newRole)
            dao.updateUser(updated)
            if (_currentUser.value?.id == userId) {
                _currentUser.value = updated
            }
        }
    }

    suspend fun deleteAccountAndData(userId: Long) {
        dao.deleteUser(userId)
        if (_currentUser.value?.id == userId) {
            _currentUser.value = null
        }
    }

    // --- Advertiser Campaigns ---
    suspend fun createAdCampaign(campaign: AdCampaign): Long {
        // Deduct budget from advertiser wallet
        val success = dao.deductUserBalance(campaign.advertiserId, campaign.budget)
        if (success > 0) {
            val id = dao.insertAdCampaign(campaign)
            val updatedUser = dao.getUserById(campaign.advertiserId)
            if (updatedUser != null && _currentUser.value?.id == campaign.advertiserId) {
                _currentUser.value = updatedUser
            }
            return id
        } else {
            throw IllegalStateException("رصيد المحفظة غير كافٍ لتمويل هذه الحملة الإعلانية ($${campaign.budget})")
        }
    }

    suspend fun updateAdCampaign(campaign: AdCampaign) {
        dao.updateAdCampaign(campaign)
    }

    fun getUserAdCampaigns(advertiserId: Long): Flow<List<AdCampaign>> = dao.getUserAdCampaigns(advertiserId)
    fun getActiveAdCampaignsByPlacement(placement: AdPlacement): Flow<List<AdCampaign>> = dao.getActiveAdCampaignsByPlacement(placement)
    fun getAllActiveAdCampaigns(): Flow<List<AdCampaign>> = dao.getAllActiveAdCampaigns()
    fun getAllAdCampaignsAdmin(): Flow<List<AdCampaign>> = dao.getAllAdCampaignsAdmin()
    fun getPendingAdCampaignsAdmin(): Flow<List<AdCampaign>> = dao.getPendingAdCampaignsAdmin()

    suspend fun updateAdCampaignStatus(campaignId: Long, status: CampaignStatus) {
        dao.updateAdCampaignStatus(campaignId, status)
    }

    suspend fun deleteAdCampaign(campaignId: Long) {
        dao.deleteAdCampaign(campaignId)
    }

    // --- Reported Posts & Moderation ---
    fun getReportedPostsAdmin(): Flow<List<BlogPost>> = dao.getReportedPostsAdmin()

    suspend fun reportPost(postId: Long, reason: String) {
        dao.reportPost(postId, reason)
    }

    suspend fun dismissReport(postId: Long) {
        dao.dismissReport(postId)
    }

    suspend fun recordCampaignImpression(campaignId: Long) {
        dao.recordCampaignImpression(campaignId)
    }

    suspend fun recordCampaignClick(campaignId: Long, cost: Double) {
        dao.recordCampaignClick(campaignId, cost)
    }

    suspend fun isLiked(userId: Long, postId: Long): Boolean {
        return dao.isLiked(userId, postId)
    }

    // --- AI Assistant ---
    suspend fun generateAiContent(prompt: String): String {
        return geminiService.generateContent(prompt)
    }
}
