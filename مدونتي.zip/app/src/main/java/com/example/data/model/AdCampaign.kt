package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CampaignStatus {
    PENDING_APPROVAL, // بانتظار موافقة الإدارة (للمعلنين)
    ACTIVE,           // نشط ومعتمد
    PAUSED,           // متوقف مؤقتاً
    REJECTED,         // مرفوض من الإدارة
    COMPLETED         // مكتمل الميزانية
}

enum class AdPlacement {
    HEADER,      // أسفل البحث
    FOOTER,      // أسفل الشاشة
    FEED_NATIVE, // بين المقالات
    IN_ARTICLE   // داخل المقال
}

@Entity(tableName = "ad_campaigns")
data class AdCampaign(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val advertiserId: Long,
    val advertiserName: String = "",
    val title: String,
    val bannerUrl: String = "",
    val targetUrl: String = "",
    val placement: AdPlacement = AdPlacement.IN_ARTICLE,
    val budget: Double = 50.0,
    val spentAmount: Double = 0.0,
    val costPerClick: Double = 0.25,
    val impressionsCount: Int = 0,
    val clicksCount: Int = 0,
    val status: CampaignStatus = CampaignStatus.ACTIVE,
    val createdAt: Long = System.currentTimeMillis()
)
