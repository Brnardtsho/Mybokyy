package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BlogDao {

    // --- Users ---
    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUsersCount(): Int

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: Long): User?

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User): Long

    @Update
    suspend fun updateUser(user: User)

    @Query("DELETE FROM users WHERE id = :userId")
    suspend fun deleteUser(userId: Long)

    // --- Categories ---
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category): Long

    @Update
    suspend fun updateCategory(category: Category)

    @Query("DELETE FROM categories WHERE id = :categoryId")
    suspend fun deleteCategory(categoryId: Long)

    // --- Blog Posts ---
    @Query("SELECT * FROM blog_posts WHERE status = 'PUBLISHED' ORDER BY createdAt DESC")
    fun getPublishedPosts(): Flow<List<BlogPost>>

    @Query("SELECT * FROM blog_posts WHERE isFeatured = 1 AND status = 'PUBLISHED' ORDER BY createdAt DESC")
    fun getFeaturedPosts(): Flow<List<BlogPost>>

    @Query("SELECT * FROM blog_posts WHERE categoryId = :categoryId AND status = 'PUBLISHED' ORDER BY createdAt DESC")
    fun getPostsByCategory(categoryId: Long): Flow<List<BlogPost>>

    @Query("SELECT * FROM blog_posts WHERE authorId = :authorId ORDER BY createdAt DESC")
    fun getPostsByAuthor(authorId: Long): Flow<List<BlogPost>>

    @Query("SELECT * FROM blog_posts WHERE id = :postId LIMIT 1")
    suspend fun getPostById(postId: Long): BlogPost?

    @Query("SELECT * FROM blog_posts WHERE id = :postId LIMIT 1")
    fun observePostById(postId: Long): Flow<BlogPost?>

    @Query("SELECT * FROM blog_posts ORDER BY createdAt DESC")
    fun getAllPostsAdmin(): Flow<List<BlogPost>>

    @Query("SELECT * FROM blog_posts WHERE status = 'PENDING_APPROVAL' ORDER BY createdAt DESC")
    fun getPendingApprovalPosts(): Flow<List<BlogPost>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: BlogPost): Long

    @Update
    suspend fun updatePost(post: BlogPost)

    @Query("DELETE FROM blog_posts WHERE id = :postId")
    suspend fun deletePost(postId: Long)

    @Query("UPDATE blog_posts SET viewsCount = viewsCount + 1 WHERE id = :postId")
    suspend fun incrementViews(postId: Long)

    @Query("UPDATE blog_posts SET likesCount = :count WHERE id = :postId")
    suspend fun updateLikesCount(postId: Long, count: Int)

    // Search query
    @Query("SELECT * FROM blog_posts WHERE status = 'PUBLISHED' AND (title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%') ORDER BY createdAt DESC")
    fun searchPosts(query: String): Flow<List<BlogPost>>

    // --- Comments ---
    @Query("SELECT * FROM comments WHERE postId = :postId ORDER BY createdAt ASC")
    fun getCommentsForPost(postId: Long): Flow<List<Comment>>

    @Query("SELECT COUNT(*) FROM comments WHERE postId = :postId")
    fun getCommentsCountForPost(postId: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: Comment): Long

    @Query("DELETE FROM comments WHERE id = :commentId")
    suspend fun deleteComment(commentId: Long)

    @Query("SELECT COUNT(*) FROM comments")
    fun getTotalCommentsCount(): Flow<Int>

    // --- Bookmarks ---
    @Query("SELECT b.postId FROM bookmarks b WHERE b.userId = :userId")
    fun getBookmarkedPostIds(userId: Long): Flow<List<Long>>

    @Query("SELECT * FROM blog_posts WHERE id IN (SELECT postId FROM bookmarks WHERE userId = :userId) AND status = 'PUBLISHED'")
    fun getBookmarkedPosts(userId: Long): Flow<List<BlogPost>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addBookmark(bookmark: Bookmark)

    @Query("DELETE FROM bookmarks WHERE userId = :userId AND postId = :postId")
    suspend fun removeBookmark(userId: Long, postId: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE userId = :userId AND postId = :postId)")
    suspend fun isBookmarked(userId: Long, postId: Long): Boolean

    // --- Likes ---
    @Query("SELECT postId FROM likes WHERE userId = :userId")
    fun getLikedPostIds(userId: Long): Flow<List<Long>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addLike(like: Like)

    @Query("DELETE FROM likes WHERE userId = :userId AND postId = :postId")
    suspend fun removeLike(userId: Long, postId: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM likes WHERE userId = :userId AND postId = :postId)")
    suspend fun isLiked(userId: Long, postId: Long): Boolean

    @Query("SELECT COUNT(*) FROM likes WHERE postId = :postId")
    suspend fun getLikesCount(postId: Long): Int

    // --- Purchases & Paywall ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: ArticlePurchase): Long

    @Query("SELECT EXISTS(SELECT 1 FROM article_purchases WHERE buyerId = :buyerId AND postId = :postId)")
    suspend fun isArticlePurchased(buyerId: Long, postId: Long): Boolean

    @Query("SELECT postId FROM article_purchases WHERE buyerId = :buyerId")
    fun getPurchasedPostIds(buyerId: Long): Flow<List<Long>>

    @Query("SELECT * FROM article_purchases WHERE authorId = :authorId ORDER BY purchasedAt DESC")
    fun getAuthorArticleSales(authorId: Long): Flow<List<ArticlePurchase>>

    @Query("SELECT * FROM article_purchases ORDER BY purchasedAt DESC")
    fun getAllArticlePurchasesAdmin(): Flow<List<ArticlePurchase>>

    // --- Withdrawal Requests ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWithdrawalRequest(request: WithdrawalRequest): Long

    @Query("SELECT * FROM withdrawal_requests WHERE userId = :userId ORDER BY requestedAt DESC")
    fun getUserWithdrawalRequests(userId: Long): Flow<List<WithdrawalRequest>>

    @Query("SELECT * FROM withdrawal_requests ORDER BY requestedAt DESC")
    fun getAllWithdrawalRequestsAdmin(): Flow<List<WithdrawalRequest>>

    @Query("UPDATE withdrawal_requests SET status = :status, rejectionReason = :reason, processedAt = :processedAt WHERE id = :requestId")
    suspend fun updateWithdrawalStatus(requestId: Long, status: WithdrawalStatus, reason: String, processedAt: Long = System.currentTimeMillis())

    // --- Ad Metrics & Monetization ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdMetric(metric: AdMetric): Long

    @Query("SELECT * FROM ad_metrics WHERE authorId = :authorId ORDER BY createdAt DESC")
    fun getUserAdMetrics(authorId: Long): Flow<List<AdMetric>>

    @Query("SELECT * FROM ad_metrics ORDER BY createdAt DESC")
    fun getAllAdMetricsAdmin(): Flow<List<AdMetric>>

    // --- User Financial Updates ---
    @Query("UPDATE users SET balance = balance + :amount, totalEarnedFromSales = totalEarnedFromSales + :salesAmount, totalEarnedFromAds = totalEarnedFromAds + :adAmount WHERE id = :userId")
    suspend fun updateUserEarnings(userId: Long, amount: Double, salesAmount: Double = 0.0, adAmount: Double = 0.0)

    @Query("UPDATE users SET balance = balance + :salesAmount, totalEarnedFromSales = totalEarnedFromSales + :salesAmount WHERE id = :userId")
    suspend fun creditAuthorArticleSale(userId: Long, salesAmount: Double)

    @Query("UPDATE users SET pendingAdHoldBalance = pendingAdHoldBalance + :adAmount, totalEarnedFromAds = totalEarnedFromAds + :adAmount WHERE id = :userId")
    suspend fun creditAuthorAdHoldEarnings(userId: Long, adAmount: Double)

    @Query("UPDATE users SET balance = balance + :releasedAmount, pendingAdHoldBalance = CASE WHEN pendingAdHoldBalance >= :releasedAmount THEN pendingAdHoldBalance - :releasedAmount ELSE 0.0 END WHERE id = :userId")
    suspend fun releaseAdHoldToAvailableBalance(userId: Long, releasedAmount: Double)

    @Query("UPDATE users SET balance = balance - :amount WHERE id = :userId AND balance >= :amount")
    suspend fun deductUserBalance(userId: Long, amount: Double): Int

    @Query("UPDATE users SET balance = balance + :amount WHERE id = :userId")
    suspend fun refundUserBalance(userId: Long, amount: Double)

    @Query("UPDATE users SET bankIban = :iban, bankSwift = :swift, bankName = :bankName, bankAccountName = :accountName, cryptoUsdtAddress = :usdtAddress, cryptoNetwork = :network, cryptoBtcAddress = :btcAddress, eWalletType = :eWalletType, eWalletAccount = :eWalletAccount WHERE id = :userId")
    suspend fun updatePayoutSettings(
        userId: Long,
        iban: String,
        swift: String,
        bankName: String,
        accountName: String,
        usdtAddress: String,
        network: String,
        btcAddress: String,
        eWalletType: String = "",
        eWalletAccount: String = ""
    )

    @Query("UPDATE users SET isAdFree = :isAdFree, adFreeExpiresAt = :expiresAt WHERE id = :userId")
    suspend fun updateUserAdFreePlan(userId: Long, isAdFree: Boolean, expiresAt: Long)

    // --- Phone, KYC, Device & TopUp ---
    @Query("UPDATE users SET phoneNumber = :phone, isPhoneVerified = :verified WHERE id = :userId")
    suspend fun updateUserPhone(userId: Long, phone: String, verified: Boolean)

    @Query("UPDATE users SET kycFullName = :fullName, kycDocumentId = :documentId, isKycVerified = :verified WHERE id = :userId")
    suspend fun updateUserKyc(userId: Long, fullName: String, documentId: String, verified: Boolean)

    @Query("UPDATE users SET isFraudFlagged = :isFlagged, fraudReason = :reason, status = IFNULL(:newStatus, status) WHERE id = :userId")
    suspend fun flagUserFraud(userId: Long, isFlagged: Boolean, reason: String, newStatus: UserStatus? = null)

    @Query("UPDATE users SET balance = balance + :amount WHERE id = :userId")
    suspend fun topUpUserWallet(userId: Long, amount: Double)

    // --- Support Tickets ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupportTicket(ticket: SupportTicket): Long

    @Query("SELECT * FROM support_tickets WHERE userId = :userId ORDER BY createdAt DESC")
    fun getUserTickets(userId: Long): Flow<List<SupportTicket>>

    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun getAllTicketsAdmin(): Flow<List<SupportTicket>>

    @Query("UPDATE support_tickets SET adminReply = :reply, status = :status, updatedAt = :updatedAt WHERE id = :ticketId")
    suspend fun updateTicketReply(ticketId: Long, reply: String, status: TicketStatus, updatedAt: Long = System.currentTimeMillis())

    // --- Advertiser Campaigns ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdCampaign(campaign: AdCampaign): Long

    @Update
    suspend fun updateAdCampaign(campaign: AdCampaign)

    @Query("SELECT * FROM ad_campaigns WHERE advertiserId = :advertiserId ORDER BY createdAt DESC")
    fun getUserAdCampaigns(advertiserId: Long): Flow<List<AdCampaign>>

    @Query("SELECT * FROM ad_campaigns WHERE status = 'ACTIVE' AND spentAmount < budget AND placement = :placement ORDER BY id DESC")
    fun getActiveAdCampaignsByPlacement(placement: AdPlacement): Flow<List<AdCampaign>>

    @Query("SELECT * FROM ad_campaigns WHERE status = 'ACTIVE' AND spentAmount < budget ORDER BY id DESC")
    fun getAllActiveAdCampaigns(): Flow<List<AdCampaign>>

    @Query("UPDATE ad_campaigns SET impressionsCount = impressionsCount + 1 WHERE id = :campaignId")
    suspend fun recordCampaignImpression(campaignId: Long)

    @Query("UPDATE ad_campaigns SET clicksCount = clicksCount + 1, spentAmount = spentAmount + :cost WHERE id = :campaignId")
    suspend fun recordCampaignClick(campaignId: Long, cost: Double)

    @Query("SELECT * FROM ad_campaigns ORDER BY id DESC")
    fun getAllAdCampaignsAdmin(): Flow<List<AdCampaign>>

    @Query("SELECT * FROM ad_campaigns WHERE status = 'PENDING_APPROVAL' ORDER BY id DESC")
    fun getPendingAdCampaignsAdmin(): Flow<List<AdCampaign>>

    @Query("UPDATE ad_campaigns SET status = :status WHERE id = :campaignId")
    suspend fun updateAdCampaignStatus(campaignId: Long, status: CampaignStatus)

    @Query("DELETE FROM ad_campaigns WHERE id = :campaignId")
    suspend fun deleteAdCampaign(campaignId: Long)

    // --- Reported Posts & Admin Control ---
    @Query("SELECT * FROM blog_posts WHERE isReported = 1 ORDER BY updatedAt DESC")
    fun getReportedPostsAdmin(): Flow<List<BlogPost>>

    @Query("UPDATE blog_posts SET isReported = 1, reportReason = :reason, updatedAt = :time WHERE id = :postId")
    suspend fun reportPost(postId: Long, reason: String, time: Long = System.currentTimeMillis())

    @Query("UPDATE blog_posts SET isReported = 0, reportReason = '' WHERE id = :postId")
    suspend fun dismissReport(postId: Long)
}

