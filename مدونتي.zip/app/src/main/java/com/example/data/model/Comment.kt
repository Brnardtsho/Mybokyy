package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "comments")
data class Comment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val postId: Long,
    val userId: Long,
    val userName: String,
    val userAvatarUrl: String = "",
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)
