package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.BlogDao
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        Category::class,
        BlogPost::class,
        Comment::class,
        Bookmark::class,
        Like::class,
        ArticlePurchase::class,
        WithdrawalRequest::class,
        AdMetric::class,
        SupportTicket::class,
        AdCampaign::class
    ],
    version = 7,
    exportSchema = false
)
abstract class BlogDatabase : RoomDatabase() {

    abstract fun blogDao(): BlogDao

    companion object {
        @Volatile
        private var INSTANCE: BlogDatabase? = null

        fun getDatabase(context: Context): BlogDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BlogDatabase::class.java,
                    "blog_master_database"
                )
                    .addCallback(DatabaseCallback(context))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val context: Context
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.blogDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: BlogDao) {
            // Seed Super Admin (مالك التطبيق والمشرف العام)
            val adminUser = User(
                id = 1L,
                email = "admin@blog.com",
                passwordHash = "admin123",
                displayName = "أحمد المشرف العام (مالك التطبيق)",
                bio = "المؤسس والمشرف العام على مدونتي. أرحب بجميع الكُتاب والمبدعين.",
                avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80",
                role = UserRole.ADMIN,
                status = UserStatus.ACTIVE
            )

            // Seed Author 1
            val author1 = User(
                id = 2L,
                email = "sara@blog.com",
                passwordHash = "author123",
                displayName = "د. سارة محمود",
                bio = "باحثة في مجالات الذكاء الاصطناعي والتكنولوجيا الحديثة ومستقبل البرمجة.",
                avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80",
                role = UserRole.AUTHOR,
                status = UserStatus.ACTIVE,
                balance = 125.50,
                pendingAdHoldBalance = 18.50,
                totalEarnedFromSales = 80.00,
                totalEarnedFromAds = 45.50,
                bankIban = "SA0380000000608010167519",
                bankSwift = "RABISARI",
                bankName = "مصرف الراجحي",
                bankAccountName = "سارة محمود علي",
                cryptoUsdtAddress = "TYD1mU89kL3q9A7XmZpRv8W2qM4NkL6PqR",
                cryptoNetwork = "TRC20"
            )

            // Seed Author 2
            val author2 = User(
                id = 3L,
                email = "omar@blog.com",
                passwordHash = "author123",
                displayName = "عمر الخالد",
                bio = "كاتب صحفي وناقد أدبي مهتم بالفلسفة والثقافة العربية المعاصرة.",
                avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
                role = UserRole.AUTHOR,
                status = UserStatus.ACTIVE,
                balance = 68.00,
                pendingAdHoldBalance = 12.00,
                totalEarnedFromSales = 40.00,
                totalEarnedFromAds = 28.00,
                cryptoUsdtAddress = "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
                cryptoNetwork = "BEP20"
            )

            // Seed Google Play Reviewer Demo Account (مختبر المراجعة والاختبار المغلق)
            val playReviewer = User(
                id = 4L,
                email = "googleplay.reviewer@example.com",
                passwordHash = "googleplay123",
                displayName = "Google Play Reviewer (Demo Account)",
                bio = "حساب مراجع Google Play مسبق التوثيق والإعداد لاختبار عمليات الشراء (IAP)، الإعلانات المكافأة، وتذاكر الدعم وسحب الأرباح.",
                avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
                role = UserRole.AUTHOR,
                status = UserStatus.ACTIVE,
                balance = 150.00,
                pendingAdHoldBalance = 35.00,
                totalEarnedFromSales = 240.00,
                totalEarnedFromAds = 95.00,
                isPhoneVerified = true,
                phoneNumber = "+1 800 555 0199",
                isKycVerified = true,
                kycFullName = "Google Play Reviewer",
                kycDocumentId = "GOOG-REV-88992",
                bankIban = "US8937000001234567890",
                bankSwift = "BOFAUS3N",
                bankName = "Bank of America",
                bankAccountName = "Google Play Reviewer",
                cryptoUsdtAddress = "0x889920112233445566778899AABBCCDDEEFF0011",
                cryptoNetwork = "ERC20"
            )

            dao.insertUser(adminUser)
            dao.insertUser(author1)
            dao.insertUser(author2)
            dao.insertUser(playReviewer)

            // Seed Categories
            val catTech = Category(id = 1L, name = "تكنولوجيا وابتكار", iconName = "Laptop", description = "أحدث اخبار التقنية البرمجة والذكاء الاصطناعي")
            val catCulture = Category(id = 2L, name = "ثقافة وفنون", iconName = "Brush", description = "مقالات في الفن المعماري والسينما والتراث")
            val catScience = Category(id = 3L, name = "علوم ورقميات", iconName = "Psychology", description = "استكشاف الكون والأبحاث العلمية والتطوير")
            val catLiterature = Category(id = 4L, name = "أدب وفكر", iconName = "MenuBook", description = "خواطر أدبية ونقد وقراءات في الكتب")
            val catLifestyle = Category(id = 5L, name = "أسلوب حياة وصحة", iconName = "FitnessCenter", description = "نصائح الصحة النفسية وتطوير الذات والإنتاجية")

            dao.insertCategory(catTech)
            dao.insertCategory(catCulture)
            dao.insertCategory(catScience)
            dao.insertCategory(catLiterature)
            dao.insertCategory(catLifestyle)

            // Seed Sample Articles
            val post1 = BlogPost(
                id = 1L,
                title = "مستقبل الذكاء الاصطناعي التوليدي في إثراء المحتوى العربي",
                summary = "قراءة شاملة لكيفية تحول أدوات الذكاء الاصطناعي إلى مساعد إبداعي للكُتاب والمحررين باللغة العربية.",
                content = """
                    يشهد العالم اليوم ثورة تكنولوجية غير مسبوقة بقيادة النماذج اللغوية الضخمة للذكاء الاصطناعي. وفي العالم العربي، أتاحت هذه التقنيات أبعاداً جديدة لتسريع عملية العصف الذهني والصياغة الإبداعية.
                    
                    أولاً: إثراء الحصيلة اللغوية
                    تساعد الأدوات الحديثة الكاتب على اختيار الألفاظ الأكثر دقة وتنوعاً، وتفادي التكرار وتدقيق القواعد النحوية بشكل لحظي.
                    
                    ثانياً: توليد الأفكار والهياكل
                    لم يعد الكاتب يعاني من حبسة الكاتب (Writer's Block)، إذ يمكن للذكاء الاصطناعي اقتراح عناوين جذابة ومحاور أساسية لأي موضوع خلال ثوانٍ.
                    
                    خاتمة:
                    يبقى العنصر البشري والحس الإنساني هو الروح الحقيقية لأي مقال، والذكاء الاصطناعي هو المحرك والأداة التمكينية.
                """.trimIndent(),
                authorId = 2L,
                authorName = "د. سارة محمود",
                authorAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80",
                categoryId = 1L,
                categoryName = "تكنولوجيا وابتكار",
                coverImageUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
                tags = "ذكاء_اصطناعي, تقنية, محتوى_عربي",
                status = PostStatus.PUBLISHED,
                isFeatured = true,
                viewsCount = 342,
                likesCount = 28
            )

            val post2 = BlogPost(
                id = 2L,
                title = "فن القراءة السريعة والعميقة: كيف تقرأ كتاباً في الأسبوع دون تقليل الاستيعاب؟",
                summary = "خطوات عملية مثبتة علمياً للجمع بين السرعة في المسح البصري والعمق في التحليل الفكري أثناء القراءة.",
                content = """
                    القراءة ليست مجرد تتبع للكلمات بالعين، بل هي عملية تفكير وتفاعل بين عقل القارئ وفكر الكاتب.
                    
                    1. تهيئة بيئة القراءة:
                    اختر مكاناً هادئاً، وتجنب المشتتات الرقمية والهواتف الذكية لمدة 30 دقيقة متواصلة.
                    
                    2. القراءة الاستكشافية (Scanning):
                    تصفح الفهرس والعناوين الفرعية والخاتمة قبل البدء في قراءة الفصل، لتكوين خريطة ذهنية مسبقة.
                    
                    3. تدوين الملاحظات على الهامش:
                    التفاعل النشط مع النص يضاعف نسبة الاحتفاظ بالمعلومات بنسبة تصل إلى 70%.
                """.trimIndent(),
                authorId = 3L,
                authorName = "عمر الخالد",
                authorAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
                categoryId = 4L,
                categoryName = "أدب وفكر",
                coverImageUrl = "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=800&q=80",
                tags = "قراءة, تطوير_الذات, كتب",
                status = PostStatus.PUBLISHED,
                isFeatured = true,
                viewsCount = 189,
                likesCount = 19
            )

            val post3 = BlogPost(
                id = 3L,
                title = "الجماليات المعمارية في المدن التاريخية: حوار الشرق والغرب",
                summary = "جولة مصورة وتحليلية للتصاميم الهندسية والنقوش الإسلامية وتأثيرها على العمارة الحديثة في العواصم العالمية.",
                content = """
                    تتميز العمارة التاريخية بكونها تجسيداً فيزيائياً لثقافة الشعوب. من أزقة الأندلس إلى حواري القاهرة القديمة، تحكي الزخارف والأقواس قصة ابتكار هندسي فريد.
                    
                    إن الاعتماد على الضوء الطبيعي وتدفق الهواء داخل الفناء الداخلي (الصحن) كان حلاً مستداماً نلجأ إليه اليوم في مفهوم المباني الخضراء.
                """.trimIndent(),
                authorId = 1L,
                authorName = "أحمد المشرف العام (مالك التطبيق)",
                authorAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80",
                categoryId = 2L,
                categoryName = "ثقافة وفنون",
                coverImageUrl = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80",
                tags = "عمارة, تاريخ, فنون",
                status = PostStatus.PUBLISHED,
                isFeatured = false,
                viewsCount = 120,
                likesCount = 15
            )

            dao.insertPost(post1)
            dao.insertPost(post2)
            dao.insertPost(post3)

            val post4 = BlogPost(
                id = 4L,
                title = "دليل الخبراء: استراتيجيات التداول والاستثمار الرقمي المتقدم 2026",
                summary = "مقال حصري خاص بالمشتركين يحتوي على تحليل لتقنيات البلوكشين والتحليل المالي للعملات الرقمية.",
                content = """
                    مرحباً بك في المقال الحصري الخاص. سنناقش في هذا الجزء المجاني العوامل الأساسية للتقييم المالي.
                    
                    الفقرة الأولى: نظرة عامة على اقتصاد البلوكشين وتقنيات Layer 2.
                    تتميز بروتوكولات Layer 2 بتخفيض رسوم المعاملات (Gas Fees) بنسبة تصل إلى 95% مما يحفز التبني الجماعي.
                    
                    --- الجزء المغلق بالدفع (Paywall) ---
                    الفقرة الثانية: التحليل الفني لشبكات DeFi والمحفظة الاستثمارية المقترحة.
                    تتوزع الأصول الموصى بها بنسبة 40% بيتكوين، 30% إيثيريوم، و20% عملات مستقرة USDT لخلق توازن مالي وحماية من التقلبات.
                    
                    الفقرة الثالثة: إدارة المخاطر وتحديد أوامر إيقاف الخسارة (Stop Loss).
                    القاعدة الذهبية في الاستثمار: لا تخاطر بأكثر من 2% من إجمالي رأس المال في صفقات ذات مخاطرة عالية.
                    
                    الفقرة الرابعة: التوقعات المستقبلية وخارطة الطريق لعام 2026 وما بعده.
                """.trimIndent(),
                authorId = 2L,
                authorName = "د. سارة محمود",
                authorAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80",
                categoryId = 3L,
                categoryName = "علوم ورقميات",
                coverImageUrl = "https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=800&q=80",
                tags = "بلوكشين, استثمار, عملات_رقمية, حصري",
                status = PostStatus.PUBLISHED,
                isFeatured = true,
                viewsCount = 450,
                likesCount = 52,
                isPaid = true,
                priceAmount = 2.99,
                currency = "USD"
            )

            dao.insertPost(post4)

            // Seed Sample Comments
            val comment1 = Comment(
                id = 1L,
                postId = 1L,
                userId = 3L,
                userName = "عمر الخالد",
                userAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
                content = "مقال رائع ودقيق جداً دكتورة سارة! بالفعل الذكاء الاصطناعي أصبح شريكاً إبداعياً لا غنى عنه."
            )

            val comment2 = Comment(
                id = 2L,
                postId = 1L,
                userId = 1L,
                userName = "أحمد المشرف العام (مالك التطبيق)",
                userAvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80",
                content = "تم تثبيت المقال في الواجهة الرئيسية بنجاح نظرًا لقيمته العلمية الممتازة."
            )

            dao.insertComment(comment1)
            dao.insertComment(comment2)

            // Seed Reviewer Withdrawal Request
            val reviewerWithdrawal = WithdrawalRequest(
                id = 1L,
                userId = 4L,
                userName = "Google Play Reviewer (Demo Account)",
                userEmail = "googleplay.reviewer@example.com",
                amount = 50.00,
                fee = 5.00,
                netAmount = 45.00,
                payoutMethod = PayoutMethod.BANK,
                accountDetails = "Bank of America (IBAN: US8937000001234567890)",
                status = WithdrawalStatus.APPROVED,
                rejectionReason = "تمت الموافقة المسبقة لاختبار النظام أثناء المراجعة المغلقة Closed Testing."
            )
            dao.insertWithdrawalRequest(reviewerWithdrawal)

            // Seed Reviewer Support Ticket
            val reviewerTicket = SupportTicket(
                id = 1L,
                userId = 4L,
                userName = "Google Play Reviewer (Demo Account)",
                userEmail = "googleplay.reviewer@example.com",
                subject = "تذكرة اختبار وتدقيق النظام - Google Play Reviewer",
                category = TicketCategory.PAYWALL_IAP,
                message = "تم فتح هذه التذكرة للاختبار المسبق أثناء فترة المراجعة والاختبار المغلق Closed Testing.",
                status = TicketStatus.RESOLVED,
                adminReply = "أهلاً بفريق مراجعة Google Play! جميع الأنظمة الشراء (IAP)، الإعلانات والتذاكر متوافقة 100%."
            )
            dao.insertSupportTicket(reviewerTicket)

            // Seed Direct Advertiser Campaign
            val sampleCampaign = AdCampaign(
                id = 1L,
                advertiserId = 4L,
                advertiserName = "Google Play Reviewer (Demo Account)",
                title = "حملة إعلانية متميزة - استضف تطبيقك على Google Play",
                bannerUrl = "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80",
                targetUrl = "https://play.google.com/store",
                placement = AdPlacement.IN_ARTICLE,
                budget = 100.0,
                spentAmount = 12.50,
                costPerClick = 0.25,
                impressionsCount = 140,
                clicksCount = 50,
                status = CampaignStatus.ACTIVE
            )
            dao.insertAdCampaign(sampleCampaign)
        }
    }
}
