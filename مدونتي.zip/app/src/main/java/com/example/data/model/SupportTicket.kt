package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TicketCategory {
    WITHDRAWAL,   // طلبات السحب والأرباح
    PAYWALL_IAP,  // الشراء والجدار المدفوع
    TECHNICAL,    // مشاكل تقنية والتطبيق
    CONTENT,      // البلاغات والمقالات
    GENERAL       // استفسارات عامة
}

enum class TicketStatus {
    OPEN,         // مفتوحة - بانتظار رد الدعم
    IN_PROGRESS,  // قيد المعالجة
    RESOLVED,     // تم الحل
    CLOSED        // مغلقة
}

@Entity(tableName = "support_tickets")
data class SupportTicket(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val userName: String,
    val userEmail: String,
    val subject: String,
    val category: TicketCategory = TicketCategory.GENERAL,
    val message: String,
    val adminReply: String = "",
    val status: TicketStatus = TicketStatus.OPEN,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
