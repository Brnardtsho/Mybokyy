package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class WithdrawalStatus {
    PENDING,  // قيد المراجعة
    APPROVED, // مقبول وتم التحويل
    REJECTED  // مرفوض
}

enum class PayoutMethod {
    BANK,     // حساب بنكي (IBAN / SWIFT)
    USDT,     // عملة رقمية USDT
    BTC,      // عملة رقمية Bitcoin
    E_WALLET  // محفظة إلكترونية (PayPal / Vodafone Cash / STC Pay)
}

@Entity(tableName = "withdrawal_requests")
data class WithdrawalRequest(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val userName: String,
    val userEmail: String,
    val amount: Double,
    val fee: Double = 0.0, // رسوم الشبكة والمعالجة المقتطعة
    val netAmount: Double = amount - fee, // صافي المبلغ المحول للكاتب
    val payoutMethod: PayoutMethod,
    val accountDetails: String,
    val status: WithdrawalStatus = WithdrawalStatus.PENDING,
    val rejectionReason: String = "",
    val requestedAt: Long = System.currentTimeMillis(),
    val processedAt: Long? = null
)
