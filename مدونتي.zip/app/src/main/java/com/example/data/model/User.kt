package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    ADMIN,      // مالك التطبيق - المشرف العام (Full Master/Supervisor)
    AUTHOR,     // كاتِب - كامل الصلاحيات في حسابه ومقالاته
    READER,     // قارئ - قراءة، تعليق، إعجاب، حفظ
    ADVERTISER  // معلن - إدارات وإطلاق الحملات الإعلانية المباشرة
}

enum class UserStatus {
    ACTIVE,    // نشط
    SUSPENDED  // محظور من الإشراف
}

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val email: String,
    val passwordHash: String,
    val displayName: String,
    val bio: String = "",
    val avatarUrl: String = "",
    val role: UserRole = UserRole.AUTHOR,
    val status: UserStatus = UserStatus.ACTIVE,
    val balance: Double = 0.0, // الرصيد الحالي المتاح للسحب
    val pendingAdHoldBalance: Double = 0.0, // الأرباح الإعلانية المعلقة خلال فترة الحجز (30 يوماً)
    val totalEarnedFromSales: Double = 0.0, // إجمالي أرباح المقالات المدفوعة
    val totalEarnedFromAds: Double = 0.0, // إجمالي أرباح الإعلانات
    // بيانات السحب البنكي
    val bankIban: String = "",
    val bankSwift: String = "",
    val bankName: String = "",
    val bankAccountName: String = "",
    // بيانات السحب الرقمي Crypto
    val cryptoUsdtAddress: String = "",
    val cryptoNetwork: String = "TRC20", // TRC20 / BEP20
    val cryptoBtcAddress: String = "",
    // المحافظ الإلكترونية (PayPal / Vodafone Cash / STC Pay)
    val eWalletType: String = "", // PayPal / Vodafone Cash / STC Pay
    val eWalletAccount: String = "",
    // اشتراك إزالة الإعلانات للقارئ (Ad-Free Subscription)
    val isAdFree: Boolean = false,
    val adFreeExpiresAt: Long = 0L,
    // الأمان وتأكيد الهوية (KYC & One Device)
    val phoneNumber: String = "",
    val isPhoneVerified: Boolean = false,
    val deviceId: String = "",
    val kycFullName: String = "",
    val kycDocumentId: String = "",
    val isKycVerified: Boolean = false,
    val isFraudFlagged: Boolean = false,
    val fraudReason: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
