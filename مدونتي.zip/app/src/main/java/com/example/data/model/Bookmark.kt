package com.example.data.model

import androidx.room.Entity

@Entity(tableName = "bookmarks", primaryKeys = ["userId", "postId"])
data class Bookmark(
    val userId: Long,
    val postId: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "likes", primaryKeys = ["userId", "postId"])
data class Like(
    val userId: Long,
    val postId: Long,
    val createdAt: Long = System.currentTimeMillis()
)
