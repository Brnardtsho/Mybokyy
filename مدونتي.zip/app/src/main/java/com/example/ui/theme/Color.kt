package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BoldPurplePrimary = Color(0xFF6750A4)
val BoldPurpleOnPrimary = Color(0xFFFFFFFF)
val BoldPurplePrimaryContainer = Color(0xFFEADDFF)
val BoldPurpleOnPrimaryContainer = Color(0xFF21005D)

val BoldSecondaryContainer = Color(0xFFE8DEF8)
val BoldOnSecondaryContainer = Color(0xFF1D192B)

val BoldTertiary = Color(0xFF7D5260)
val BoldTertiaryContainer = Color(0xFFD0BCFF)
val BoldOnTertiaryContainer = Color(0xFF381E72)

val BoldBackgroundLight = Color(0xFFFDF8FF)
val BoldSurfaceLight = Color(0xFFFFFFFF)
val BoldSurfaceVariant = Color(0xFFF7F2FA)
val BoldOnSurface = Color(0xFF1C1B1F)
val BoldOnSurfaceVariant = Color(0xFF49454F)
val BoldOutline = Color(0xFFCAC4D0)

val AdminPurple = Color(0xFF6750A4)
val SuccessGreen = Color(0xFF2E7D32)
val GoldAccent = Color(0xFF7D5260)

