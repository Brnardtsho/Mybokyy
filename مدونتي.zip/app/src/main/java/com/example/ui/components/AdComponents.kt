package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.GetApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdCampaign
import com.example.data.model.AdPlacement
import com.example.ui.theme.GoldAccent

enum class AdLocation {
    HEADER,      // أعلى الصفحة تحت البحث
    FOOTER,      // الفوتر أسفل الشاشة
    FEED_NATIVE, // بين كروت القوائم (كل 3 مقالات)
    IN_ARTICLE   // داخل المقال (بعد العنوان، الفقرات، الخاتمة)
}

enum class AdProviderMode {
    WEB_ADSENSE,   // إعلانات جوجل أدسينس للويب
    MOBILE_ADMOB   // إعلانات جوجل أدموب للهواتف
}

@Composable
fun AdBannerCard(
    location: AdLocation,
    modifier: Modifier = Modifier,
    providerMode: AdProviderMode = AdProviderMode.MOBILE_ADMOB,
    activeCampaigns: List<AdCampaign> = emptyList(),
    onCampaignClicked: (AdCampaign) -> Unit = {},
    onAdClicked: () -> Unit = {}
) {
    var isDismissed by remember { mutableStateOf(false) }

    if (isDismissed) return

    val matchingPlacement = when (location) {
        AdLocation.HEADER -> AdPlacement.HEADER
        AdLocation.FOOTER -> AdPlacement.FOOTER
        AdLocation.FEED_NATIVE -> AdPlacement.FEED_NATIVE
        AdLocation.IN_ARTICLE -> AdPlacement.IN_ARTICLE
    }

    val activeDirectCampaign = remember(activeCampaigns, location) {
        activeCampaigns.find { it.placement == matchingPlacement }
            ?: activeCampaigns.firstOrNull()
    }

    val bgGradient = when (location) {
        AdLocation.HEADER -> Brush.horizontalGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
        AdLocation.FOOTER -> Brush.horizontalGradient(listOf(Color(0xFF09101D), Color(0xFF1E293B)))
        AdLocation.FEED_NATIVE -> Brush.linearGradient(listOf(Color(0xFF1F2937), Color(0xFF111827)))
        AdLocation.IN_ARTICLE -> Brush.horizontalGradient(listOf(Color(0xFF27272A), Color(0xFF18181B)))
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, GoldAccent.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .clickable {
                if (activeDirectCampaign != null) {
                    onCampaignClicked(activeDirectCampaign)
                } else {
                    onAdClicked()
                }
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(bgGradient)
                .padding(12.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Ad Badge Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (activeDirectCampaign != null) MaterialTheme.colorScheme.primary else GoldAccent,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = if (activeDirectCampaign != null) "إعلان مباشر 📢" else "إعلان مُرعَى",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (activeDirectCampaign != null) Color.White else Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (activeDirectCampaign != null)
                                "حملة معلن: ${activeDirectCampaign.advertiserName}"
                            else if (providerMode == AdProviderMode.MOBILE_ADMOB)
                                "Google AdMob Native"
                            else
                                "Google AdSense Responsive Unit",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.LightGray,
                                fontSize = 10.sp
                            )
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق الإعلان",
                        tint = Color.Gray,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { isDismissed = true }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Ad Content Body
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Campaign,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeDirectCampaign?.title ?: when (location) {
                                AdLocation.HEADER -> "استضافة سحابية فائقة السرعة مع حماية DDoS مجاناً"
                                AdLocation.FOOTER -> "حمّل تطبيق تداول العملات والتداول الآلي اليوم!"
                                AdLocation.FEED_NATIVE -> "احصل على خصم 50% على دورات الذكاء الاصطناعي البرمجية"
                                AdLocation.IN_ARTICLE -> "حلول البرمجة والمحاسبة الذكية للشركات والمؤسسات"
                            },
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (activeDirectCampaign != null) "رابط الحملة: ${activeDirectCampaign.targetUrl}" else "انقر هنا لتجربة مجانية لمدة 14 يوماً بدون بطاقة ائتمانية.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.LightGray,
                                fontSize = 11.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (activeDirectCampaign != null) {
                                onCampaignClicked(activeDirectCampaign)
                            } else {
                                onAdClicked()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "زيارة الرابط",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PwaInstallBanner(
    modifier: Modifier = Modifier
) {
    var isDismissed by remember { mutableStateOf(false) }

    if (isDismissed) return

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Outlined.GetApp,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "تثبيت تطبيق مدونتي (PWA)",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                    Text(
                        text = "تصفح أسرع، بدون إنترنت، وتنبيهات أولاً بأول",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { /* Simulated PWA installation */ },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تثبيت الان", fontSize = 11.sp)
                }
                IconButton(
                    onClick = { isDismissed = true },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
    }
}
