package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.ShopTwo
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Shop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlogPost
import com.example.data.model.User
import com.example.ui.theme.GoldAccent
import kotlinx.coroutines.delay

@Composable
fun PaywallCard(
    post: BlogPost,
    currentUser: User?,
    onUnlockClick: (paymentMethod: String) -> Unit,
    onUnlockViaRewardedAd: () -> Unit = {}
) {
    var showPaymentModal by remember { mutableStateOf(false) }
    var showRewardedAdModal by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.5.dp, GoldAccent, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                color = GoldAccent.copy(alpha = 0.2f),
                shape = RoundedCornerShape(50)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = GoldAccent,
                    modifier = Modifier
                        .padding(12.dp)
                        .size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "هذا المقال مدفوع ومغلق حصرياً",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                textAlign = TextAlign.Center
            )

            Text(
                text = "لقد قرأت 20% من المعاينة المجانية. اشترِ المقال عبر Google Play IAP أو شاهد إعلان مكافأة لفتحه مجاناً.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Surface(
                color = GoldAccent,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                Text(
                    text = "السعر: ${post.priceAmount} ${post.currency}",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = Color.Black,
                        fontWeight = FontWeight.ExtraBold
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PaywallBenefitRow("دعم مباشر للكاتب (${post.authorName}) بنسبة 80%")
                PaywallBenefitRow("امتثال كامل لسياسات الشراء المباشر Google Play IAP")
                PaywallBenefitRow("إمكانية مشاهدة إعلان مكافأة لفتح المقال بدون خيار الدفع")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Primary Buy Button (Google Play IAP & Balance)
            Button(
                onClick = { showPaymentModal = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.ShopTwo, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "شراء عبر Google Play IAP / المحفظة",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Secondary Rewarded Video Ad Button
            OutlinedButton(
                onClick = { showRewardedAdModal = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🎬 شاهد فيديو إعلاني قصير لفتح المقال مجاناً",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }

    if (showPaymentModal) {
        PaymentMethodDialog(
            post = post,
            currentUser = currentUser,
            onDismiss = { showPaymentModal = false },
            onConfirmPayment = { method ->
                showPaymentModal = false
                onUnlockClick(method)
            }
        )
    }

    if (showRewardedAdModal) {
        RewardedAdDialog(
            post = post,
            onDismiss = { showRewardedAdModal = false },
            onAdCompleted = {
                showRewardedAdModal = false
                onUnlockViaRewardedAd()
            }
        )
    }
}

@Composable
fun RewardedAdDialog(
    post: BlogPost,
    onDismiss: () -> Unit,
    onAdCompleted: () -> Unit
) {
    var timeLeft by remember { mutableStateOf(5) }
    var isCompleted by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (timeLeft > 0) {
            delay(1000L)
            timeLeft--
        }
        isCompleted = true
    }

    AlertDialog(
        onDismissRequest = { if (isCompleted) onDismiss() },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("إعلان مكافآت (Google Rewarded Video Ad)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "شاهد هذا الفيديو الإعلاني القصير لفتح مقال (${post.title}) مجاناً دون الحاجة للدفع.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (!isCompleted) {
                            CircularProgressIndicator(color = GoldAccent)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("جاري عرض الإعلان التفاعلي... ($timeLeft ثوانٍ)", color = Color.White, fontSize = 13.sp)
                        } else {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.Green, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("اكتملت مشاهدة الإعلان بنجاح!", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("تم احتساب مكافأة الكاتب والمنصة ✅", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onAdCompleted,
                enabled = isCompleted,
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
            ) {
                Text("فتح المقال الآن", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            if (!isCompleted) {
                TextButton(onClick = onDismiss) {
                    Text("إلغاء الإعلان")
                }
            }
        }
    )
}

@Composable
private fun PaywallBenefitRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp)
        )
    }
}

@Composable
fun PaymentMethodDialog(
    post: BlogPost,
    currentUser: User?,
    onDismiss: () -> Unit,
    onConfirmPayment: (method: String) -> Unit
) {
    var selectedMethod by remember { mutableStateOf("GOOGLE_PLAY") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "دفع وفتح المقال (Google Play Compliance)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "المقال: ${post.title}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                    text = "المبلغ المطلوب: ${post.priceAmount} ${post.currency}",
                    style = MaterialTheme.typography.bodySmall.copy(color = GoldAccent, fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "اختر وسيلة الدفع:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 1: Google Play IAP Direct
                PaymentOptionCard(
                    title = "Google Play In-App Billing (IAP)",
                    subtitle = "شراء مباشر آمن معتمد من متجر قوقل بلاي",
                    icon = Icons.Outlined.Shop,
                    isSelected = selectedMethod == "GOOGLE_PLAY",
                    onClick = { selectedMethod = "GOOGLE_PLAY" }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 2: Wallet Balance
                PaymentOptionCard(
                    title = "خصم من رصيد محفظة التطبيق",
                    subtitle = "الرصيد المتاح: ${String.format("%.2f", currentUser?.balance ?: 0.0)} $",
                    icon = Icons.Outlined.AccountBalanceWallet,
                    isSelected = selectedMethod == "BALANCE",
                    onClick = { selectedMethod = "BALANCE" }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 3: Credit Card
                PaymentOptionCard(
                    title = "بطاقة ائتمان / مدى / Apple Pay",
                    subtitle = "دفع فوري آمن ومباشر",
                    icon = Icons.Outlined.CreditCard,
                    isSelected = selectedMethod == "CARD",
                    onClick = { selectedMethod = "CARD" }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmPayment(selectedMethod) },
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
            ) {
                Text("تأكيد الدفع والفتح", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun PaymentOptionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) GoldAccent.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) GoldAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = isSelected, onClick = onClick)
            Spacer(modifier = Modifier.width(8.dp))
            Icon(imageVector = icon, contentDescription = null, tint = if (isSelected) GoldAccent else MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp))
            }
        }
    }
}
