package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.AdminPurple

@Composable
fun ProfileScreen(
    currentUser: User?,
    onOpenAdminPanel: () -> Unit,
    onLogout: () -> Unit,
    onUpdateProfile: (User) -> Unit,
    onOpenAuth: () -> Unit = {},
    onOpenEarnings: () -> Unit = {},
    onUpdateUserRole: (UserRole) -> Unit = {},
    onSubscribeAdFree: () -> Unit = {},
    onDeleteAccount: () -> Unit = {}
) {
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }

    if (currentUser == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = null,
                    modifier = Modifier.size(72.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "أهلاً بك في مدونتي",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "قم بتسجيل الدخول أو إنشاء حساب جديد لنشر مقالاتك وإدارتها",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onOpenAuth,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Login, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تسجيل الدخول / إنشاء حساب")
                }
            }
        }
        return
    }

    var isEditing by remember { mutableStateOf(false) }
    var displayNameInput by remember(currentUser) { mutableStateOf(currentUser.displayName) }
    var bioInput by remember(currentUser) { mutableStateOf(currentUser.bio) }

    val isAdFreeActive = currentUser.isAdFree && currentUser.adFreeExpiresAt > System.currentTimeMillis()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 100.dp)
            .testTag("profile_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // User Avatar
        if (currentUser.avatarUrl.isNotBlank()) {
            AsyncImage(
                model = currentUser.avatarUrl,
                contentDescription = currentUser.displayName,
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Surface(
                modifier = Modifier.size(90.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = currentUser.displayName.take(1),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Multi-Role Switcher Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "دور الحساب الحالي: ${when(currentUser.role) { UserRole.READER -> "📖 قارئ"; UserRole.AUTHOR -> "✍️ كاتب ومبدع"; UserRole.ADVERTISER -> "📢 معلن وممول إعلانات"; UserRole.ADMIN -> "👑 المشرف العام" }}",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "يمكنك التبديل والتنقل بين الأدوار والترقية بضغطة زر دون الحاجة لإنشاء حساب جديد:",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = currentUser.role == UserRole.READER,
                        onClick = { onUpdateUserRole(UserRole.READER) },
                        label = { Text("📖 قارئ", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = currentUser.role == UserRole.AUTHOR,
                        onClick = { onUpdateUserRole(UserRole.AUTHOR) },
                        label = { Text("✍️ كاتب", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = currentUser.role == UserRole.ADVERTISER,
                        onClick = { onUpdateUserRole(UserRole.ADVERTISER) },
                        label = { Text("📢 معلن", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (isEditing) {
            OutlinedTextField(
                value = displayNameInput,
                onValueChange = { displayNameInput = it },
                label = { Text("الاسم") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = bioInput,
                onValueChange = { bioInput = it },
                label = { Text("البيو / السيرة الذاتية") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        onUpdateProfile(
                            currentUser.copy(
                                displayName = displayNameInput,
                                bio = bioInput
                            )
                        )
                        isEditing = false
                    }
                ) {
                    Text("حفظ التغييرات")
                }
                TextButton(onClick = { isEditing = false }) {
                    Text("إلغاء")
                }
            }
        } else {
            Text(
                text = currentUser.displayName,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold)
            )
            Text(
                text = currentUser.email,
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )

            if (currentUser.bio.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = currentUser.bio,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            TextButton(onClick = { isEditing = true }) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تعديل البيانات")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Divider()
        Spacer(modifier = Modifier.height(24.dp))

        // Ad-Free Subscription Plan Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isAdFreeActive) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(
                            Icons.Default.Block,
                            contentDescription = null,
                            tint = if (isAdFreeActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text("خطة القراءة بدون إعلانات (Ad-Free)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                text = if (isAdFreeActive) "الخطة نشطة ومفعلة 🟢" else "إزالة جميع البنرات وإعلانات المقالات",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (!isAdFreeActive) {
                        Button(
                            onClick = onSubscribeAdFree,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("4.99$ / شهر", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Author Earnings & Payouts Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text("الأرباح والرصيد الحالي", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("رصيدك: ${String.format("%.2f", currentUser.balance)} $", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Button(onClick = onOpenEarnings, shape = RoundedCornerShape(12.dp)) {
                    Text("إدارة الأرباح")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Google Play Reviewer / Closed Testing Info Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    Text("جاهزية المراجعة والاختبار المغلق (Google Play Closed Testing)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "التطبيق متوافق 100% مع متطلبات الـ 20 اختباري وسياسات Google Play (IAP, Rewarded Ads, Paywall Content & KYC Verification).",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (currentUser.role == UserRole.ADMIN) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AdminPurple.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = AdminPurple)
                        Text("لوحة التحكم والإشراف", fontWeight = FontWeight.Bold, color = AdminPurple)
                    }
                    Button(onClick = onOpenAdminPanel, colors = ButtonDefaults.buttonColors(containerColor = AdminPurple)) {
                        Text("فتح اللوحة")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Privacy Policy & Delete Account (Google Play Compliance)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextButton(
                onClick = { showPrivacyPolicyDialog = true },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("سياسة الخصوصية", fontSize = 12.sp)
            }

            TextButton(
                onClick = { showDeleteAccountDialog = true },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حذف الحساب والبيانات", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
        ) {
            Icon(Icons.Default.Logout, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("تسجيل الخروج")
        }
    }

    // Privacy Policy Dialog
    if (showPrivacyPolicyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyPolicyDialog = false },
            icon = { Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("سياسة الخصوصية وحماية البيانات - مدونتي", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "تطبيق مدونتي يلتزم بحماية خصوصية المستخدمين وبياناتهم الشخصية وفق معايير Google Play Policy:\n\n" +
                                "1. جمع البيانات: نجمع البريد الإلكتروني والاسم ورقم الهاتف (عند التوثيق) بغرض إنشاء الحساب وتفعيل السحوبات المالية.\n" +
                                "2. أمان المعاملات: المعاملات المالية والشراء عبر Google Play IAP محمية ومشفرة بالكامل.\n" +
                                "3. حظر البوتات والسياسات الإعلانية: الإعلانات المدمجة تتوافق مع متطلبات AdMob وضوابط الكثافة الإعلانية (< 30%).\n" +
                                "4. حق حذف البيانات: يحق للمستخدم طلب حذف حسابه وجميع بياناته نهائياً في أي وقت من زر حذف الحساب.",
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyPolicyDialog = false }) {
                    Text("موافق وإغلاق")
                }
            }
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("تأكيد حذف الحساب والبيانات نهائياً", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
            text = {
                Text("هل أنت أصل ومتبين من طلب حذف حسابك نهائياً؟ سيتم مسح جميع مقالاتك، رصيد المحفظة، والسجلات التابعة لك دون إمكانية للاستعادة وفق قوانين Google Play.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountDialog = false
                        onDeleteAccount()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، احذف حسابي نهائياً")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
