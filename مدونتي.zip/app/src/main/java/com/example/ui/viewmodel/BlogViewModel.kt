package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.BlogDatabase
import com.example.data.model.*
import com.example.data.repository.BlogRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    CATEGORIES,
    MY_POSTS,
    BOOKMARKS,
    ADMIN_PANEL,
    PROFILE,
    POST_DETAIL,
    POST_EDITOR,
    AUTH,
    EARNINGS,
    SUPPORT_TICKETS
}

data class BlogUiState(
    val currentScreen: Screen = Screen.HOME,
    val selectedPostId: Long? = null,
    val editingPostId: Long? = null,
    val selectedCategoryId: Long? = null,
    val searchQuery: String = "",
    val authEmail: String = "",
    val authPass: String = "",
    val authName: String = "",
    val authBio: String = "",
    val authRole: UserRole = UserRole.AUTHOR,
    val authErrorMessage: String? = null,
    val isLoginTab: Boolean = true,
    val aiPrompt: String = "",
    val aiGeneratedResult: String = "",
    val isAiLoading: Boolean = false,
    val showAiQADialog: Boolean = false,
    val aiQAPrompt: String = "",
    val aiQAResponse: String = "",
    val isAiQALoading: Boolean = false,
    val snackbarMessage: String? = null,
    val isDarkMode: Boolean? = null, // null = system, true = dark, false = light
    val appLanguage: String = "ar", // "ar" or "en"
    val soundEffectsEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val showTermsDialog: Boolean = false,
    val showPrivacyDialog: Boolean = false
)

class BlogViewModel(application: Application) : AndroidViewModel(application) {

    val repository: BlogRepository

    private val _uiState = MutableStateFlow(BlogUiState())
    val uiState: StateFlow<BlogUiState> = _uiState.asStateFlow()

    init {
        val database = BlogDatabase.getDatabase(application)
        repository = BlogRepository(database.blogDao())
    }

    val currentUser: StateFlow<User?> = repository.currentUser

    // Data Flows
    val publishedPosts: StateFlow<List<BlogPost>> = repository.publishedPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val featuredPosts: StateFlow<List<BlogPost>> = repository.featuredPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPostsAdmin: StateFlow<List<BlogPost>> = repository.allPostsAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsersAdmin: StateFlow<List<User>> = repository.allUsersAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingPosts: StateFlow<List<BlogPost>> = repository.pendingApprovalPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalCommentsCount: StateFlow<Int> = repository.totalCommentsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val adminWithdrawals: StateFlow<List<WithdrawalRequest>> = repository.getAllWithdrawalRequestsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPurchases: StateFlow<List<ArticlePurchase>> = repository.getAllArticlePurchasesAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdMetrics: StateFlow<List<AdMetric>> = repository.getAllAdMetricsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSupportTickets: StateFlow<List<SupportTicket>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getUserSupportTickets(user.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSupportTicketsAdmin: StateFlow<List<SupportTicket>> = repository.getAllSupportTicketsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reportedPostsAdmin: StateFlow<List<BlogPost>> = repository.getReportedPostsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdCampaignsAdmin: StateFlow<List<AdCampaign>> = repository.getAllAdCampaignsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingAdCampaignsAdmin: StateFlow<List<AdCampaign>> = repository.getPendingAdCampaignsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResults: StateFlow<List<BlogPost>> = _uiState
        .flatMapLatest { state ->
            val catId = state.selectedCategoryId
            val query = state.searchQuery.trim()
            val baseFlow = if (query.isBlank()) {
                if (catId != null) repository.getPostsByCategory(catId) else repository.publishedPosts
            } else {
                repository.searchPosts(query).map { list ->
                    if (catId != null) list.filter { it.categoryId == catId } else list
                }
            }
            baseFlow
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarkedPostIds: StateFlow<Set<Long>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getBookmarkedPostIds(user.id)
        }
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val likedPostIds: StateFlow<Set<Long>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getLikedPostIds(user.id)
        }
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val purchasedPostIds: StateFlow<Set<Long>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getPurchasedPostIds(user.id)
        }
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val myPosts: StateFlow<List<BlogPost>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getPostsByAuthor(user.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userWithdrawalRequests: StateFlow<List<WithdrawalRequest>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getUserWithdrawalRequests(user.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val authorSales: StateFlow<List<ArticlePurchase>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getAuthorArticleSales(user.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val authorAdMetrics: StateFlow<List<AdMetric>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getUserAdMetrics(user.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminWithdrawalRequests: StateFlow<List<WithdrawalRequest>> = repository.getAllWithdrawalRequestsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminAllPurchases: StateFlow<List<ArticlePurchase>> = repository.getAllArticlePurchasesAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminAllAdMetrics: StateFlow<List<AdMetric>> = repository.getAllAdMetricsAdmin()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarkedPosts: StateFlow<List<BlogPost>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else repository.getBookmarkedPosts(user.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Navigation Controls ---
    fun navigateTo(screen: Screen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun openPostDetail(postId: Long) {
        _uiState.update {
            it.copy(
                selectedPostId = postId,
                currentScreen = Screen.POST_DETAIL
            )
        }
    }

    fun openPostEditor(postId: Long? = null) {
        _uiState.update {
            it.copy(
                editingPostId = postId,
                currentScreen = Screen.POST_EDITOR,
                aiGeneratedResult = ""
            )
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectCategory(categoryId: Long?) {
        _uiState.update { it.copy(selectedCategoryId = categoryId) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    fun showSnackbar(msg: String) {
        _uiState.update { it.copy(snackbarMessage = msg) }
    }

    // --- Auth Actions ---
    fun setAuthTab(isLogin: Boolean) {
        _uiState.update { it.copy(isLoginTab = isLogin, authErrorMessage = null) }
    }

    fun updateAuthFields(
        email: String? = null,
        pass: String? = null,
        name: String? = null,
        bio: String? = null,
        role: UserRole? = null
    ) {
        _uiState.update {
            it.copy(
                authEmail = email ?: it.authEmail,
                authPass = pass ?: it.authPass,
                authName = name ?: it.authName,
                authBio = bio ?: it.authBio,
                authRole = role ?: it.authRole
            )
        }
    }

    fun submitAuth() {
        val state = _uiState.value
        viewModelScope.launch {
            if (state.isLoginTab) {
                val res = repository.login(state.authEmail, state.authPass)
                if (res.isSuccess) {
                    showSnackbar("تم تسجيل الدخول بنجاح! أهلاً بك.")
                    navigateTo(Screen.HOME)
                } else {
                    _uiState.update { it.copy(authErrorMessage = res.exceptionOrNull()?.message) }
                }
            } else {
                val res = repository.register(
                    email = state.authEmail,
                    password = state.authPass,
                    displayName = state.authName,
                    bio = state.authBio,
                    role = state.authRole
                )
                if (res.isSuccess) {
                    showSnackbar("تم إنشاء الحساب بنجاح! مرحباً بك في مدونتي.")
                    navigateTo(Screen.HOME)
                } else {
                    _uiState.update { it.copy(authErrorMessage = res.exceptionOrNull()?.message) }
                }
            }
        }
    }

    fun loginAsSuperAdmin() {
        viewModelScope.launch {
            repository.loginAsSuperAdmin()
            showSnackbar("تم تسجيل الدخول كمالك التطبيق (المشرف العام) بجميع الصلاحيات.")
            navigateTo(Screen.ADMIN_PANEL)
        }
    }

    fun loginAsGooglePlayReviewer() {
        viewModelScope.launch {
            repository.loginAsGooglePlayReviewer()
            showSnackbar("تم تسجيل الدخول بحساب مراجع Google Play التجريبي ($150.00 رصيد، توثيق كلي مسبق).")
            navigateTo(Screen.HOME)
        }
    }

    fun updateProfile(user: User) {
        viewModelScope.launch {
            repository.updateProfile(user)
            showSnackbar("تم تحديث بيانات الملف الشخصي بنجاح")
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            showSnackbar("تم تسجيل الخروج بنجاح.")
            navigateTo(Screen.HOME)
        }
    }

    // --- Post Actions ---
    fun savePost(
        title: String,
        content: String,
        summary: String,
        categoryId: Long,
        categoryName: String,
        coverImageUrl: String,
        tags: String,
        asDraft: Boolean,
        isPaid: Boolean = false,
        priceAmount: Double = 0.0
    ) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }

        viewModelScope.launch {
            val status = if (asDraft) PostStatus.DRAFT else PostStatus.PUBLISHED
            val existingId = uiState.value.editingPostId ?: 0L
            val existingPost = if (existingId != 0L) repository.getPostById(existingId) else null

            val postToSave = BlogPost(
                id = existingId,
                title = title.ifBlank { "بدون عنوان" },
                content = content,
                summary = summary,
                authorId = existingPost?.authorId ?: user.id,
                authorName = existingPost?.authorName ?: user.displayName,
                authorAvatarUrl = existingPost?.authorAvatarUrl ?: user.avatarUrl,
                categoryId = categoryId,
                categoryName = categoryName,
                coverImageUrl = coverImageUrl.ifBlank { "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=800&q=80" },
                tags = tags,
                status = status,
                isFeatured = existingPost?.isFeatured ?: false,
                viewsCount = existingPost?.viewsCount ?: 0,
                likesCount = existingPost?.likesCount ?: 0,
                isPaid = isPaid,
                priceAmount = priceAmount
            )

            repository.savePost(postToSave)
            showSnackbar(if (asDraft) "تم حفظ المقال كمسودة" else "تم نشر المقال بنجاح!")
            navigateTo(Screen.MY_POSTS)
        }
    }

    fun deletePost(postId: Long) {
        viewModelScope.launch {
            repository.deletePost(postId)
            showSnackbar("تم حذف المقال.")
            if (uiState.value.selectedPostId == postId) {
                navigateTo(Screen.HOME)
            }
        }
    }

    fun toggleFeatured(postId: Long, currentFeatured: Boolean) {
        viewModelScope.launch {
            repository.setFeaturedPost(postId, !currentFeatured)
            showSnackbar(if (!currentFeatured) "تم تثبيت المقال في واجهة المالك" else "تم إلغاء التثبيت")
        }
    }

    fun updatePostStatus(postId: Long, status: PostStatus) {
        viewModelScope.launch {
            repository.updatePostStatus(postId, status)
            showSnackbar("تم تحديث حالة المقال بنجاح")
        }
    }

    // --- Admin User & Category Controls ---
    fun toggleUserBan(user: User) {
        viewModelScope.launch {
            repository.toggleUserBanStatus(user)
            val action = if (user.status == UserStatus.ACTIVE) "حظر" else "إلغاء حظر"
            showSnackbar("تم $action المستخدم ${user.displayName}")
        }
    }

    fun addCategory(name: String, description: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.addCategory(name, "Folder", description)
            showSnackbar("تمت إضافة التصنيف الجديد بنجاح")
        }
    }

    fun deleteCategory(categoryId: Long) {
        viewModelScope.launch {
            repository.deleteCategory(categoryId)
            showSnackbar("تم حذف التصنيف")
        }
    }

    // --- Interaction Actions ---
    fun toggleBookmark(postId: Long) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }
        viewModelScope.launch {
            val isAdded = repository.toggleBookmark(user.id, postId)
            showSnackbar(if (isAdded) "تم حفظ المقال في المفضلة" else "تمت إزالة المقال من المفضلة")
        }
    }

    fun toggleLike(postId: Long) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }
        viewModelScope.launch {
            repository.toggleLike(user.id, postId)
        }
    }

    fun addComment(postId: Long, content: String) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }
        if (content.isBlank()) return
        viewModelScope.launch {
            repository.addComment(postId, user, content)
            showSnackbar("تمت إضافة التعليق بنجاح")
        }
    }

    fun deleteComment(commentId: Long) {
        viewModelScope.launch {
            repository.deleteComment(commentId)
            showSnackbar("تم حذف التعليق")
        }
    }

    // --- Monetization & Paywall Actions ---
    fun purchaseArticle(post: BlogPost, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val buyer = currentUser.value
        if (buyer == null) {
            navigateTo(Screen.AUTH)
            onComplete(false, "يرجى تسجيل الدخول أولاً لشراء المقال")
            return
        }
        viewModelScope.launch {
            val result = repository.purchaseArticle(buyer, post)
            if (result.isSuccess) {
                val msg = result.getOrNull() ?: "تم الشراء بنجاح"
                showSnackbar(msg)
                onComplete(true, msg)
            } else {
                val err = result.exceptionOrNull()?.message ?: "فشلت عملية الشراء"
                showSnackbar(err)
                onComplete(false, err)
            }
        }
    }

    fun recordAdImpression(postId: Long, authorId: Long, adType: String) {
        viewModelScope.launch {
            repository.recordAdImpression(postId, authorId, adType)
        }
    }

    fun submitWithdrawalRequest(
        amount: Double,
        method: PayoutMethod,
        details: String,
        onComplete: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            onComplete(false, "يرجى تسجيل الدخول أولاً")
            return
        }
        viewModelScope.launch {
            val res = repository.submitWithdrawalRequest(user, amount, method, details)
            if (res.isSuccess) {
                val msg = res.getOrNull() ?: "تم إرسال طلب السحب بنجاح"
                showSnackbar(msg)
                onComplete(true, msg)
            } else {
                val err = res.exceptionOrNull()?.message ?: "فشل طلب السحب"
                showSnackbar(err)
                onComplete(false, err)
            }
        }
    }

    fun processWithdrawalRequest(requestId: Long, userId: Long, amount: Double, approve: Boolean, reason: String = "") {
        viewModelScope.launch {
            repository.processWithdrawalRequest(requestId, userId, amount, approve, reason)
            showSnackbar(if (approve) "تمت الموافقة على طلب السحب" else "تم رفض طلب السحب وإعادة الرصيد للمستخدم")
        }
    }

    fun updatePayoutSettings(
        iban: String,
        swift: String,
        bankName: String,
        accountName: String,
        usdtAddress: String,
        network: String,
        btcAddress: String,
        eWalletType: String = "",
        eWalletAccount: String = ""
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.updatePayoutSettings(user.id, iban, swift, bankName, accountName, usdtAddress, network, btcAddress, eWalletType, eWalletAccount)
            showSnackbar("تم حفظ بيانات وسيلة السحب بنجاح")
        }
    }

    // --- Ad-Free Experience Subscription ---
    fun purchaseAdFreePlan(useWallet: Boolean = false) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }
        viewModelScope.launch {
            val result = repository.purchaseAdFreePlan(user.id, useWallet)
            if (result.isSuccess) {
                showSnackbar(result.getOrNull() ?: "تم تفعيل اشتراك التصفح بدون إعلانات بنجاح!")
            } else {
                showSnackbar(result.exceptionOrNull()?.message ?: "فشل تفعيل الاشتراك")
            }
        }
    }

    // --- Google Play IAP Balance Top-Up ---
    fun topUpWalletViaIap(amount: Double, packageTitle: String) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }
        viewModelScope.launch {
            repository.topUpUserWallet(user.id, amount)
            showSnackbar("تم شحن رصيد المحفظة بمبلغ $amount$ بنجاح عبر Google Play Billing ($packageTitle)")
        }
    }

    // --- Rewarded Video Ad Unlock ---
    fun unlockArticleViaRewardedAd(post: BlogPost, onComplete: () -> Unit = {}) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }
        viewModelScope.launch {
            repository.unlockArticleViaRewardedAd(user, post)
            showSnackbar("تم مشاهدة الإعلان الإنسيابي بنجاح! تم فتح المقال مجاناً")
            onComplete()
        }
    }

    // --- Phone Verification & KYC ---
    fun verifyPhoneNumber(phone: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.updateUserPhone(user.id, phone, true)
            showSnackbar("تم تفعيل رقم الهاتف ($phone) بنجاح عبر رمز OTP")
        }
    }

    fun submitKycVerification(fullName: String, documentId: String) {
        val user = currentUser.value ?: return
        if (fullName.isBlank() || documentId.isBlank()) {
            showSnackbar("يرجى إدخال الاسم الثلاثي ورقم الهوية الكامل")
            return
        }
        viewModelScope.launch {
            repository.updateUserKyc(user.id, fullName, documentId, true)
            showSnackbar("تم توثيق الهوية (KYC) بنجاح وتفعيل إمكانية سحب الأرباح")
        }
    }

    // --- Fraud & Anti-Bot Security ---
    fun flagUserFraud(userId: Long, isFlagged: Boolean, reason: String) {
        viewModelScope.launch {
            repository.flagUserFraud(userId, isFlagged, reason)
            showSnackbar(if (isFlagged) "تم حظر الحساب وإلغاء صلاحية السحب لمخالفة معايير الأمان" else "تم إلغاء الحظر وتفعيل الحساب")
        }
    }

    // --- User Role Switch & Account Deletion (Google Play Policy) ---
    fun updateUserRole(newRole: UserRole) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.updateUserRole(user.id, newRole)
            showSnackbar("تم تغيير دور الحساب إلى (${when(newRole) { UserRole.READER -> "قارئ"; UserRole.AUTHOR -> "كاتب ومبدع"; UserRole.ADVERTISER -> "معلن وممول إعلانات"; UserRole.ADMIN -> "مشرف عام" }}) بنجاح")
        }
    }

    fun deleteAccountAndData() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.deleteAccountAndData(user.id)
            showSnackbar("تم حذف الحساب وجميع البيانات التابعة له نهائياً وفق سياسة الخصوصية.")
            navigateTo(Screen.HOME)
        }
    }

    // --- Advertiser Campaigns ---
    val activeAdCampaigns: StateFlow<List<AdCampaign>> = combine(
        repository.getAllActiveAdCampaigns(),
        currentUser
    ) { campaigns, user ->
        if (user != null && user.isAdFree && (user.adFreeExpiresAt == 0L || user.adFreeExpiresAt > System.currentTimeMillis())) {
            emptyList()
        } else {
            campaigns
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userAdCampaigns: StateFlow<List<AdCampaign>> = currentUser
        .flatMapLatest { user ->
            if (user != null) repository.getUserAdCampaigns(user.id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createAdCampaign(
        title: String,
        bannerUrl: String,
        targetUrl: String,
        placement: AdPlacement,
        budget: Double,
        costPerClick: Double,
        onSuccess: () -> Unit = {}
    ) {
        val user = currentUser.value ?: return
        if (title.isBlank() || targetUrl.isBlank() || budget < 5.0) {
            showSnackbar("يرجى إدخال عنوان الإعلان، الرابط الموجه، وميزانية لا تقل عن $5")
            return
        }
        viewModelScope.launch {
            try {
                // إعلانات المعلنين تذهب بانتظار موافقة الإدارة (PENDING_APPROVAL) وإعلانات المشرف تتفعل فوراً
                val initialStatus = if (user.role == UserRole.ADMIN) CampaignStatus.ACTIVE else CampaignStatus.PENDING_APPROVAL
                val campaign = AdCampaign(
                    advertiserId = user.id,
                    advertiserName = user.displayName,
                    title = title,
                    bannerUrl = if (bannerUrl.isBlank()) "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80" else bannerUrl,
                    targetUrl = targetUrl,
                    placement = placement,
                    budget = budget,
                    costPerClick = costPerClick,
                    status = initialStatus
                )
                repository.createAdCampaign(campaign)
                if (initialStatus == CampaignStatus.PENDING_APPROVAL) {
                    showSnackbar("تم إرسال إعلانك بنجاح! الإعلان الآن في حالة الانتظار (PENDING) لموافقة المشرف العام.")
                } else {
                    showSnackbar("تم إطلاق الحملة الإعلانية وتفعيلها في التطبيق بنجاح!")
                }
                onSuccess()
            } catch (e: Exception) {
                showSnackbar(e.message ?: "حدث خطأ أثناء إنشاء الحملة")
            }
        }
    }

    fun approveAdCampaign(campaignId: Long) {
        viewModelScope.launch {
            repository.updateAdCampaignStatus(campaignId, CampaignStatus.ACTIVE)
            showSnackbar("تمت الموافقة على الإعلان وتفعيله في التطبيق بنجاح!")
        }
    }

    fun rejectAdCampaign(campaignId: Long) {
        viewModelScope.launch {
            repository.updateAdCampaignStatus(campaignId, CampaignStatus.REJECTED)
            showSnackbar("تم رفض الإعلان.")
        }
    }

    fun deleteAdCampaign(campaignId: Long) {
        viewModelScope.launch {
            repository.deleteAdCampaign(campaignId)
            showSnackbar("تم حذف الحملة الإعلانية نهائياً.")
        }
    }

    fun recordCampaignClick(campaign: AdCampaign) {
        viewModelScope.launch {
            repository.recordCampaignClick(campaign.id, campaign.costPerClick)
        }
    }

    fun reportContent(postId: Long, reason: String) {
        viewModelScope.launch {
            repository.reportPost(postId, reason)
            showSnackbar("تم استلام بلاغك ($reason) وإحالته للوحة تحكم الإدارة للمراجعة والحذف الفوري.")
        }
    }

    fun dismissPostReport(postId: Long) {
        viewModelScope.launch {
            repository.dismissReport(postId)
            showSnackbar("تم تجاهل البلاغ وتثبيت المقال.")
        }
    }

    // --- Support Tickets ---
    fun createSupportTicket(subject: String, category: TicketCategory, message: String, onDone: () -> Unit = {}) {
        val user = currentUser.value
        if (user == null) {
            navigateTo(Screen.AUTH)
            return
        }
        if (subject.isBlank() || message.isBlank()) {
            showSnackbar("يرجى كتابة عنوان ورسالة التذكرة")
            return
        }
        viewModelScope.launch {
            val ticket = SupportTicket(
                userId = user.id,
                userName = user.displayName,
                userEmail = user.email,
                subject = subject,
                category = category,
                message = message
            )
            repository.createSupportTicket(ticket)
            showSnackbar("تم فتح تذكرة الدعم بنجاح وسيرد الفريق الإداري عليك في أقرب وقت")
            onDone()
        }
    }

    fun replyToSupportTicket(ticketId: Long, reply: String, status: TicketStatus) {
        if (reply.isBlank()) return
        viewModelScope.launch {
            repository.replyToSupportTicket(ticketId, reply, status)
            showSnackbar("تم إرسال الرد وتحديث حالة التذكرة")
        }
    }

    // --- Gemini AI Assistant & Suite ---
    fun setAiQADialogOpen(open: Boolean) {
        _uiState.update { it.copy(showAiQADialog = open) }
    }

    fun updateAiQAPrompt(prompt: String) {
        _uiState.update { it.copy(aiQAPrompt = prompt) }
    }

    fun askPlatformAiQA(query: String) {
        if (query.isBlank()) return
        _uiState.update { it.copy(isAiQALoading = true) }
        viewModelScope.launch {
            val published = publishedPosts.value.take(5).joinToString("\n") { "• عنوان: ${it.title} (تصنيف: ${it.categoryName}) - ملخص: ${it.summary.ifBlank { it.content.take(80) }}" }
            val systemContext = "أنت المساعد الذكي الرسمي لمنصة 'مدونتي'. أجب على سؤال القارئ باللغة العربية بطريقة ملهمة، واقترح عليه مقالات وتصنيفات مفيدة ذات صلة من المنصة إن أمكن:\nالمقالات المتاحة حالياً:\n$published\n\nسؤال المستخدم: $query"
            val response = repository.generateAiContent(systemContext)
            _uiState.update {
                it.copy(
                    aiQAResponse = response,
                    isAiQALoading = false
                )
            }
        }
    }

    fun generateWithAi(prompt: String) {
        if (prompt.isBlank()) return
        _uiState.update { it.copy(isAiLoading = true) }
        viewModelScope.launch {
            val result = repository.generateAiContent(prompt)
            _uiState.update {
                it.copy(
                    aiGeneratedResult = result,
                    isAiLoading = false
                )
            }
        }
    }

    fun generateAdCopy(productOrTopic: String, onResult: (String) -> Unit) {
        if (productOrTopic.isBlank()) return
        viewModelScope.launch {
            val prompt = "صغ إعلاناً تسويقياً جذاباً ومختصراً باللغة العربية (Ad Copy) للمنتج/الخدمة التالية: '$productOrTopic'. يجب أن يتضمن نصاً حماسياً مع دعوة واضحة لاتخاذ إجراء (Call to Action)."
            val result = repository.generateAiContent(prompt)
            onResult(result)
        }
    }

    fun setDarkMode(isDark: Boolean?) {
        _uiState.update { it.copy(isDarkMode = isDark) }
    }

    fun setAppLanguage(lang: String) {
        _uiState.update { it.copy(appLanguage = lang) }
    }

    fun setSoundEffects(enabled: Boolean) {
        _uiState.update { it.copy(soundEffectsEnabled = enabled) }
    }

    fun setNotifications(enabled: Boolean) {
        _uiState.update { it.copy(notificationsEnabled = enabled) }
    }

    fun setShowTermsDialog(show: Boolean) {
        _uiState.update { it.copy(showTermsDialog = show) }
    }

    fun setShowPrivacyDialog(show: Boolean) {
        _uiState.update { it.copy(showPrivacyDialog = show) }
    }
}
