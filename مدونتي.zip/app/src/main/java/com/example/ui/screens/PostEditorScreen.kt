package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.BlogPost
import com.example.data.model.Category

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostEditorScreen(
    editingPost: BlogPost?,
    categories: List<Category>,
    aiGeneratedResult: String,
    isAiLoading: Boolean,
    onBackClick: () -> Unit,
    onSavePost: (
        title: String,
        content: String,
        summary: String,
        categoryId: Long,
        categoryName: String,
        coverImageUrl: String,
        tags: String,
        asDraft: Boolean,
        isPaid: Boolean,
        priceAmount: Double
    ) -> Unit,
    onGenerateWithAi: (String) -> Unit
) {
    var title by remember(editingPost) { mutableStateOf(editingPost?.title ?: "") }
    var content by remember(editingPost) { mutableStateOf(editingPost?.content ?: "") }
    var summary by remember(editingPost) { mutableStateOf(editingPost?.summary ?: "") }
    var tags by remember(editingPost) { mutableStateOf(editingPost?.tags ?: "") }
    var isPaid by remember(editingPost) { mutableStateOf(editingPost?.isPaid ?: false) }
    var priceAmountText by remember(editingPost) { mutableStateOf(editingPost?.priceAmount?.toString() ?: "2.99") }
    var coverImageUrl by remember(editingPost) {
        mutableStateOf(
            editingPost?.coverImageUrl.takeIf { !it.isNullOrBlank() }
                ?: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=800&q=80"
        )
    }

    var selectedCategory by remember(editingPost, categories) {
        mutableStateOf(
            categories.find { it.id == editingPost?.categoryId } ?: categories.firstOrNull()
        )
    }

    var showAiDialog by remember { mutableStateOf(false) }
    var aiPromptInput by remember { mutableStateOf("") }

    val presetCovers = listOf(
        "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text(if (editingPost == null) "مقال جديد" else "تعديل المقال", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.Close, contentDescription = "إلغاء")
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            if (selectedCategory != null) {
                                onSavePost(
                                    title,
                                    content,
                                    summary,
                                    selectedCategory!!.id,
                                    selectedCategory!!.name,
                                    coverImageUrl,
                                    tags,
                                    true,
                                    isPaid,
                                    priceAmountText.toDoubleOrNull() ?: 0.0
                                )
                            }
                        }
                    ) {
                        Text("حفظ مسودة")
                    }

                    Button(
                        onClick = {
                            if (selectedCategory != null) {
                                onSavePost(
                                    title,
                                    content,
                                    summary,
                                    selectedCategory!!.id,
                                    selectedCategory!!.name,
                                    coverImageUrl,
                                    tags,
                                    false,
                                    isPaid,
                                    priceAmountText.toDoubleOrNull() ?: 0.0
                                )
                            }
                        },
                        modifier = Modifier.padding(end = 8.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("نشر المقال")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)
                .verticalScroll(rememberScrollState())
                .testTag("post_editor_scroll_column"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // AI Assistant Prompt Bar
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                        Column {
                            Text("مساعد الكتابة الذكي (Gemini)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("ولّد أفكاراً وعناوين أو صغ المقال بذكاء", fontSize = 11.sp)
                        }
                    }

                    Button(
                        onClick = { showAiDialog = true },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("فتح المساعد")
                    }
                }
            }

            // Title Field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان المقال") },
                placeholder = { Text("مثال: مستقبل الذكاء الاصطناعي...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_title_input"),
                shape = RoundedCornerShape(16.dp),
                textStyle = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            // Category Selection Dropdown
            Text("اختر التصنيف:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory?.id == cat.id,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.name) },
                        leadingIcon = {
                            if (selectedCategory?.id == cat.id) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        }
                    )
                }
            }

            // Cover Image Selection
            Text("صورة الغلاف:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presetCovers) { url ->
                    Box(
                        modifier = Modifier
                            .size(90.dp, 60.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { coverImageUrl = url }
                            .background(if (coverImageUrl == url) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .padding(if (coverImageUrl == url) 2.dp else 0.dp)
                    ) {
                        AsyncImage(
                            model = url,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            // Summary Field
            OutlinedTextField(
                value = summary,
                onValueChange = { summary = it },
                label = { Text("ملخص قصير للمقال (موجز الواجهة)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                maxLines = 3
            )

            // Content Body Field
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("محتوى المقال") },
                placeholder = { Text("اكتب تفاصيل مقالك هنا بالتفصيل...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .testTag("post_content_input"),
                shape = RoundedCornerShape(16.dp),
                maxLines = 20
            )

            // Tags Field
            OutlinedTextField(
                value = tags,
                onValueChange = { tags = it },
                label = { Text("الوسوم / Tags (مفصولة بفاصلة)") },
                placeholder = { Text("تقنية, أدب, ذكاء_اصطناعي") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            // Paywall Article Switch & Price Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("تحويل إلى مقال مدفوع (Paywall)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Text("سيظهر للقارئ 20% فقط كـ معاينة، ويحصل الكاتب على 80% من المبيعات تلقائياً.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = isPaid,
                            onCheckedChange = { isPaid = it }
                        )
                    }

                    if (isPaid) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = priceAmountText,
                            onValueChange = { priceAmountText = it },
                            label = { Text("سعر فتح المقال ($ / USDT)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // AI Writing Assistant Dialog
    if (showAiDialog) {
        AlertDialog(
            onDismissRequest = { showAiDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    Text("مساعد الكاتب الإبداعي (Gemini AI)", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("اختر مهمة سريعة للذكاء الاصطناعي أو اكتب طلباً مخصصاً:", fontSize = 12.sp)

                    // Quick Action Presets
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            SuggestionChip(
                                onClick = {
                                    val cat = selectedCategory?.name ?: "عام"
                                    aiPromptInput = "اقترح 4 أفكار مقالات ملهمة في تصنيف $cat"
                                    onGenerateWithAi(aiPromptInput)
                                },
                                label = { Text("💡 أفكار مقالات", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    val currentT = title.ifBlank { "مستقبل التقنية والابتكار" }
                                    aiPromptInput = "اقترح 3 عناوين جذابة ومتوافقة مع محركات البحث لمقال عن: $currentT"
                                    onGenerateWithAi(aiPromptInput)
                                },
                                label = { Text("✨ عناوين مقترحة", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    val currentC = content.ifBlank { "اكتب نصاً لتحسينه" }
                                    aiPromptInput = "قم بتحسين أسلوب والتدقيق اللغوي للنص التالي:\n$currentC"
                                    onGenerateWithAi(aiPromptInput)
                                },
                                label = { Text("✍️ تدقيق وتحسين الأسلوب", fontSize = 11.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    val t = title.ifBlank { "مقال تقني" }
                                    aiPromptInput = "اقترح قائمة بـ 6 وسوم وكلمات مفتاحية (SEO Tags) مفصولة بفواصل لمقال بعنوان: $t"
                                    onGenerateWithAi(aiPromptInput)
                                },
                                label = { Text("🏷️ وسوم SEO", fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = aiPromptInput,
                        onValueChange = { aiPromptInput = it },
                        placeholder = { Text("اكتب طلبك للذكاء الاصطناعي...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3
                    )

                    Button(
                        onClick = { onGenerateWithAi(aiPromptInput) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isAiLoading && aiPromptInput.isNotBlank(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isAiLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري المعالجة بالذكاء الاصطناعي...")
                        } else {
                            Text("توليد بواسطة الذكاء الاصطناعي")
                        }
                    }

                    if (aiGeneratedResult.isNotBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("النتيجة المقترحة:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(aiGeneratedResult, fontSize = 13.sp, lineHeight = 19.sp)

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            if (title.isBlank()) title = aiGeneratedResult.lines().firstOrNull()?.replace("^[0-9•\\.\\-\\s]+".toRegex(), "") ?: ""
                                            else content += "\n\n" + aiGeneratedResult
                                            showAiDialog = false
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                                    ) {
                                        Text("إدراج في المحتوى", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            tags = aiGeneratedResult.replace("\n", ", ")
                                            showAiDialog = false
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("تعيين كوسوم SEO", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAiDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}

private fun String?.isNullOfBlank(): Boolean = this == null || this.isBlank()
