package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = BoldPurplePrimaryContainer,
    onPrimary = BoldPurpleOnPrimaryContainer,
    primaryContainer = BoldPurplePrimary,
    onPrimaryContainer = BoldPurplePrimaryContainer,
    secondaryContainer = BoldSecondaryContainer,
    onSecondaryContainer = BoldOnSecondaryContainer,
    tertiary = BoldTertiaryContainer,
    background = BoldOnSurface,
    surface = BoldOnSurfaceVariant,
    surfaceVariant = BoldOnSurface
  )

private val LightColorScheme =
  lightColorScheme(
    primary = BoldPurplePrimary,
    onPrimary = BoldPurpleOnPrimary,
    primaryContainer = BoldPurplePrimaryContainer,
    onPrimaryContainer = BoldPurpleOnPrimaryContainer,
    secondaryContainer = BoldSecondaryContainer,
    onSecondaryContainer = BoldOnSecondaryContainer,
    tertiary = BoldTertiary,
    onTertiary = BoldPurpleOnPrimary,
    tertiaryContainer = BoldTertiaryContainer,
    onTertiaryContainer = BoldOnTertiaryContainer,
    background = BoldBackgroundLight,
    onBackground = BoldOnSurface,
    surface = BoldSurfaceLight,
    onSurface = BoldOnSurface,
    surfaceVariant = BoldSurfaceVariant,
    onSurfaceVariant = BoldOnSurfaceVariant,
    outline = BoldOutline
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

