package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AdCampaign
import com.example.data.model.BlogPost
import com.example.data.model.Comment
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.components.AdBannerCard
import com.example.ui.components.AdLocation
import com.example.ui.components.PaywallCard
import com.example.ui.theme.GoldAccent
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    post: BlogPost?,
    currentUser: User?,
    comments: List<Comment>,
    aiSummary: String,
    isAiLoading: Boolean,
    isBookmarked: Boolean = false,
    isLiked: Boolean = false,
    isPurchased: Boolean = false,
    activeAdCampaigns: List<AdCampaign> = emptyList(),
    onBackClick: () -> Unit,
    onBookmarkToggle: (Long) -> Unit,
    onLikeToggle: (Long) -> Unit,
    onAddComment: (Long, String) -> Unit,
    onDeleteComment: (Long) -> Unit,
    onGenerateAiSummary: (String) -> Unit,
    onUnlockClick: (method: String) -> Unit = {},
    onUnlockViaRewardedAd: () -> Unit = {},
    onRecordAdImpression: (postId: Long, authorId: Long, adType: String) -> Unit = { _, _, _ -> },
    onAdCampaignClick: (AdCampaign) -> Unit = {},
    onReportPost: (postId: Long, reason: String) -> Unit = { _, _ -> },
    onDeletePost: ((Long) -> Unit)? = null
) {
    if (post == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val context = LocalContext.current
    var newCommentText by remember { mutableStateOf("") }
    var showReportDialog by remember { mutableStateOf(false) }
    var showAdminDeleteDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("محتوى غير لائق أو مخالف") }

    // Anti-Bot & Time/Scroll Validation State
    var activeReadingSeconds by remember { mutableStateOf(0) }
    var hasScrolledArticle by remember { mutableStateOf(false) }
    var isImpressionCredited by remember { mutableStateOf(false) }
    val lazyListState = androidx.compose.foundation.lazy.rememberLazyListState()

    // Detect scrolling
    LaunchedEffect(lazyListState.isScrollInProgress) {
        if (lazyListState.isScrollInProgress) {
            hasScrolledArticle = true
        }
    }

    // Timer for 15 seconds active stay
    LaunchedEffect(post.id) {
        while (activeReadingSeconds < 15) {
            delay(1000L)
            activeReadingSeconds++
        }
    }

    // Credit ad impression once 15 seconds stay + scroll complete
    LaunchedEffect(activeReadingSeconds, hasScrolledArticle) {
        if (activeReadingSeconds >= 15 && hasScrolledArticle && !isImpressionCredited) {
            isImpressionCredited = true
            onRecordAdImpression(post.id, post.authorId, "VALIDATED_TIME_15S")
        }
    }

    val formattedDate = remember(post.createdAt) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale("ar"))
        sdf.format(Date(post.createdAt))
    }

    val readingTime = remember(post.content) {
        val wordCount = post.content.trim().split("\\s+".toRegex()).size
        val minutes = maxOf(1, (wordCount / 180))
        "$minutes دقيقة قراءة"
    }

    fun sharePost() {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "اقرأ هذا المقال المميز في مدونتي:\n\n*${post.title}*\n\nبقلم: ${post.authorName}\n\n${post.summary.ifBlank { post.content.take(150) }}...")
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "مشاركة المقال عبر")
        context.startActivity(shareIntent)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text(post.categoryName, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { sharePost() }) {
                        Icon(Icons.Outlined.Share, contentDescription = "مشاركة")
                    }
                    IconButton(onClick = { onBookmarkToggle(post.id) }) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "حفظ",
                            tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { onLikeToggle(post.id) }) {
                        Icon(
                            imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "إعجاب",
                            tint = if (isLiked) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { showReportDialog = true }) {
                        Icon(
                            imageVector = Icons.Outlined.Flag,
                            contentDescription = "إبلاغ عن محتوى",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                    if (currentUser != null && currentUser.role == UserRole.ADMIN) {
                        IconButton(onClick = { showAdminDeleteDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.DeleteForever,
                                contentDescription = "حذف المقال كإدارة",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                AdBannerCard(
                    location = AdLocation.FOOTER,
                    modifier = Modifier.padding(8.dp),
                    activeCampaigns = activeAdCampaigns,
                    onCampaignClicked = onAdCampaignClick,
                    onAdClicked = { onRecordAdImpression(post.id, post.authorId, "FOOTER") }
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .testTag("post_detail_lazy_column"),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            // Anti-Bot & Fraud Prevention Banner
            item {
                Surface(
                    color = if (isImpressionCredited) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isImpressionCredited) Icons.Default.Verified else Icons.Default.Shield,
                                contentDescription = null,
                                tint = if (isImpressionCredited) Color(0xFF2E7D32) else MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = if (isImpressionCredited) "تم تحسين القراءة واحتساب أرباح الإعلانات للكاتب ✅" else "معايير الأمان (Anti-Bot): يلزم 15 ثانية قراءة نشطة + التمرير",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isImpressionCredited) Color(0xFF1B5E20) else MaterialTheme.colorScheme.onTertiaryContainer
                                )
                                Text(
                                    text = if (isImpressionCredited) "ترافيك آمن وموثق 100% يمتثل لسياسات Google AdMob" else "الوقت المنقضي: $activeReadingSeconds / 15 ثانية | التمرير: ${if (hasScrolledArticle) "نعم ✅" else "في الانتظار ⏳"}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }

            // Cover Image
            if (post.coverImageUrl.isNotBlank()) {
                item {
                    AsyncImage(
                        model = post.coverImageUrl,
                        contentDescription = post.title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // Article Header Details
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = post.title,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 24.sp,
                            lineHeight = 32.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Author Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (post.authorAvatarUrl.isNotBlank()) {
                                AsyncImage(
                                    model = post.authorAvatarUrl,
                                    contentDescription = post.authorName,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Surface(
                                    modifier = Modifier.size(44.dp),
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = post.authorName.take(1),
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }

                            Column {
                                Text(
                                    text = post.authorName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "$formattedDate • $readingTime • ${post.viewsCount} مشاهدة",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        // AI Summarizer Trigger Button
                        Button(
                            onClick = {
                                onGenerateAiSummary("قم بتلخيص هذا المقال باللغة العربية في 3 نقاط محددة:\n\nالعنوان: ${post.title}\nالمحتوى: ${post.content}")
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ملخص الذكاء الاصطناعي", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // AI Generated Summary Display Card
                    if (isAiLoading) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                Text("جاري توليد تلخيص ذكي للمقال بواسطة Gemini AI...", fontSize = 13.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    } else if (aiSummary.isNotBlank()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text("الملخص الذكي (Gemini AI)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = aiSummary,
                                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    // Top In-Article Ad
                    AdBannerCard(
                        location = AdLocation.IN_ARTICLE,
                        activeCampaigns = activeAdCampaigns,
                        onCampaignClicked = onAdCampaignClick,
                        onAdClicked = { onRecordAdImpression(post.id, post.authorId, "IN_ARTICLE_TOP") }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val isAuthorOrAdmin = currentUser?.id == post.authorId || currentUser?.role == UserRole.ADMIN
                    val isLocked = post.isPaid && !isPurchased && !isAuthorOrAdmin

                    LaunchedEffect(post.id) {
                        onRecordAdImpression(post.id, post.authorId, "IN_ARTICLE_VIEW")
                    }

                    val paragraphs = remember(post.content) { post.content.split("\n\n") }

                    if (isLocked) {
                        // Render 20% Preview (at least 1 paragraph)
                        val previewCount = maxOf(1, (paragraphs.size * 0.20).toInt())
                        val previewParagraphs = paragraphs.take(previewCount)

                        previewParagraphs.forEach { para ->
                            Text(
                                text = para,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontSize = 17.sp,
                                    lineHeight = 28.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Render Paywall Lock Card
                        PaywallCard(
                            post = post,
                            currentUser = currentUser,
                            onUnlockClick = { method -> onUnlockClick(method) },
                            onUnlockViaRewardedAd = onUnlockViaRewardedAd
                        )

                    } else {
                        // Render full article with ads injected every 3 paragraphs
                        paragraphs.forEachIndexed { index, para ->
                            Text(
                                text = para,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontSize = 17.sp,
                                    lineHeight = 28.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Ad every 3 paragraphs
                            if ((index + 1) % 3 == 0 && index < paragraphs.size - 1) {
                                AdBannerCard(
                                    location = AdLocation.IN_ARTICLE,
                                    activeCampaigns = activeAdCampaigns,
                                    onCampaignClicked = onAdCampaignClick,
                                    onAdClicked = { onRecordAdImpression(post.id, post.authorId, "IN_ARTICLE_INTERSTITIAL") }
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                            }
                        }
                    }

                    // Closing In-Article Ad before Comments
                    Spacer(modifier = Modifier.height(16.dp))
                    AdBannerCard(
                        location = AdLocation.IN_ARTICLE,
                        activeCampaigns = activeAdCampaigns,
                        onCampaignClicked = onAdCampaignClick,
                        onAdClicked = { onRecordAdImpression(post.id, post.authorId, "IN_ARTICLE_BOTTOM") }
                    )

                    // Tags
                    if (post.tags.isNotBlank()) {
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Tag, contentDescription = null, modifier = Modifier.size(16.dp))
                            post.tags.split(",").forEach { tag ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = "#${tag.trim()}",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    // Comments Title
                    Text(
                        text = "التعليقات (${comments.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Add Comment Input Box
                    if (currentUser != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newCommentText,
                                onValueChange = { newCommentText = it },
                                placeholder = { Text("اكتب تعليقاً على هذا المقال...") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                singleLine = true
                            )
                            IconButton(
                                onClick = {
                                    if (newCommentText.isNotBlank()) {
                                        onAddComment(post.id, newCommentText)
                                        newCommentText = ""
                                    }
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(
                                        MaterialTheme.colorScheme.primary,
                                        shape = CircleShape
                                    )
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "إرسال", tint = Color.White)
                            }
                        }
                    } else {
                        Text(
                            text = "قم بتسجيل الدخول لتتمكن من إضافة تعليق.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }

            // Comments List
            items(comments) { comment ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                modifier = Modifier.size(32.dp),
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = comment.userName.take(1),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = comment.userName,
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = comment.content,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }

                        val canDelete = currentUser?.role == UserRole.ADMIN || (currentUser != null && currentUser.id == comment.userId)
                        if (canDelete) {
                            IconButton(
                                onClick = { onDeleteComment(comment.id) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إبلاغ عن محتوى غير لائق", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("يرجى اختيار سبب البلاغ لإرساله لإدارة المنصة للمراجعة الفورية:")
                    val reasons = listOf(
                        "محتوى غير لائق أو مخالف للآداب",
                        "محتوى مسروق أو انتهاك حقوق ملكية",
                        "معلومات مضللة أو احتيال",
                        "إعلانات مزعجة أو سبام"
                    )
                    reasons.forEach { reason ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { reportReason = reason }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = (reportReason == reason),
                                onClick = { reportReason = reason }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(reason, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReportPost(post.id, reportReason)
                        showReportDialog = false
                        Toast.makeText(context, "تم استلام البلاغ وسيتم اتخاذ الإجراء اللازم فوراً", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("إرسال البلاغ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showAdminDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showAdminDeleteDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حذف المقال كإدارة (ADMIN)", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text("بصفتك مشرفاً عاماً، هل أنت متأكد من رغبتك في حذف هذا المقال نهائياً من المنصة وإزالته من جميع الأقسام؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAdminDeleteDialog = false
                        onDeletePost?.invoke(post.id)
                        Toast.makeText(context, "تم حذف المقال من المنصة بنجاح بواسطة الإدارة", Toast.LENGTH_SHORT).show()
                        onBackClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف المقال نهائياً")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdminDeleteDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
