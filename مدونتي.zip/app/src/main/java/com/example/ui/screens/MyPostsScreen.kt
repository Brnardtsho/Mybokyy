package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BlogPost
import com.example.data.model.PostStatus
import com.example.data.model.User
import com.example.ui.components.BlogPostCard

@Composable
fun MyPostsScreen(
    currentUser: User?,
    myPosts: List<BlogPost>,
    bookmarkedPostIds: Set<Long> = emptySet(),
    likedPostIds: Set<Long> = emptySet(),
    onOpenAuth: () -> Unit,
    onCreatePost: () -> Unit,
    onPostClick: (Long) -> Unit,
    onEditPost: (Long) -> Unit,
    onDeletePost: (Long) -> Unit,
    onBookmarkToggle: (Long) -> Unit,
    onLikeToggle: (Long) -> Unit
) {
    if (currentUser == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "يتطلب تسجيل الدخول",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "قم بتسجيل الدخول لتتمكن من إنشاء إدارة منشوراتك ومسوداتك الخاصة بصلاحيات كاملة.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = onOpenAuth,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("تسجيل الدخول / حساب جديد")
                    }
                }
            }
        }
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: الكل, 1: منشور, 2: مسودات

    val filteredPosts = remember(myPosts, selectedTab) {
        when (selectedTab) {
            1 -> myPosts.filter { it.status == PostStatus.PUBLISHED }
            2 -> myPosts.filter { it.status == PostStatus.DRAFT }
            else -> myPosts
        }
    }

    val totalViews = remember(myPosts) { myPosts.sumOf { it.viewsCount } }
    val totalLikes = remember(myPosts) { myPosts.sumOf { it.likesCount } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("my_posts_lazy_column"),
        contentPadding = PaddingValues(bottom = 88.dp, start = 16.dp, end = 16.dp, top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Author Statistics Summary Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "لوحة التحكم الخاصة بك: ${currentUser.displayName}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${myPosts.size}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            Text("إجمالي المقالات", style = MaterialTheme.typography.labelSmall)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$totalViews", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            Text("المشاهدات", style = MaterialTheme.typography.labelSmall)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$totalLikes", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            Text("الإعجابات", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // Action Row & Filter Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier.weight(1f),
                    divider = {}
                ) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                        Text("الكل (${myPosts.size})", fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                    }
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                        Text("المنشورة", fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                    }
                    Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                        Text("المسودات", fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = onCreatePost,
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(Icons.Default.Add, contentDescription = "كتابة مقال")
                }
            }
        }

        if (filteredPosts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لا توجد مقالات في هذا القسم",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        } else {
            items(filteredPosts) { post ->
                BlogPostCard(
                    post = post,
                    currentUser = currentUser,
                    isBookmarked = bookmarkedPostIds.contains(post.id),
                    isLiked = likedPostIds.contains(post.id),
                    onPostClick = { onPostClick(post.id) },
                    onBookmarkToggle = { onBookmarkToggle(post.id) },
                    onLikeToggle = { onLikeToggle(post.id) },
                    onEditPost = { onEditPost(post.id) },
                    onDeletePost = { onDeletePost(post.id) }
                )
            }
        }
    }
}
