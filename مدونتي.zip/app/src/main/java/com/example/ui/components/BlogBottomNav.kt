package com.example.ui.components

import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.AdminPurple
import com.example.ui.viewmodel.Screen

@Composable
fun BlogBottomNav(
    currentScreen: Screen,
    currentUser: User?,
    onNavigate: (Screen) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .navigationBarsPadding()
            .testTag("bottom_navigation_bar"),
        tonalElevation = 8.dp
    ) {
        // Home Tab
        NavigationBarItem(
            selected = currentScreen == Screen.HOME,
            onClick = { onNavigate(Screen.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "الرئيسية"
                )
            },
            label = { Text("الرئيسية", fontSize = 11.sp) },
            modifier = Modifier.testTag("nav_tab_home")
        )

        // Categories Tab
        NavigationBarItem(
            selected = currentScreen == Screen.CATEGORIES,
            onClick = { onNavigate(Screen.CATEGORIES) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.CATEGORIES) Icons.Filled.Category else Icons.Outlined.Category,
                    contentDescription = "التصنيفات"
                )
            },
            label = { Text("التصنيفات", fontSize = 11.sp) },
            modifier = Modifier.testTag("nav_tab_categories")
        )

        // My Posts Tab
        NavigationBarItem(
            selected = currentScreen == Screen.MY_POSTS || currentScreen == Screen.POST_EDITOR,
            onClick = { onNavigate(Screen.MY_POSTS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.MY_POSTS) Icons.Filled.Article else Icons.Outlined.Article,
                    contentDescription = "منشوراتي"
                )
            },
            label = { Text("منشوراتي", fontSize = 11.sp) },
            modifier = Modifier.testTag("nav_tab_my_posts")
        )

        // Bookmarks Tab
        NavigationBarItem(
            selected = currentScreen == Screen.BOOKMARKS,
            onClick = { onNavigate(Screen.BOOKMARKS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.BOOKMARKS) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                    contentDescription = "المحفوظات"
                )
            },
            label = { Text("المحفوظات", fontSize = 11.sp) },
            modifier = Modifier.testTag("nav_tab_bookmarks")
        )

        // Admin Panel Tab (If Super Admin)
        if (currentUser?.role == UserRole.ADMIN) {
            NavigationBarItem(
                selected = currentScreen == Screen.ADMIN_PANEL,
                onClick = { onNavigate(Screen.ADMIN_PANEL) },
                icon = {
                    Icon(
                        imageVector = if (currentScreen == Screen.ADMIN_PANEL) Icons.Filled.AdminPanelSettings else Icons.Outlined.AdminPanelSettings,
                        contentDescription = "لوحة الإشراف",
                        tint = AdminPurple
                    )
                },
                label = { Text("الإشراف", fontSize = 11.sp, color = AdminPurple) },
                modifier = Modifier.testTag("nav_tab_admin_panel")
            )
        }

        // Profile Tab
        NavigationBarItem(
            selected = currentScreen == Screen.PROFILE || currentScreen == Screen.AUTH,
            onClick = { onNavigate(if (currentUser == null) Screen.AUTH else Screen.PROFILE) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                    contentDescription = "حسابي"
                )
            },
            label = { Text("حسابي", fontSize = 11.sp) },
            modifier = Modifier.testTag("nav_tab_profile")
        )
    }
}
