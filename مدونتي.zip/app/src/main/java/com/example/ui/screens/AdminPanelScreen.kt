package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.theme.AdminPurple
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    currentUser: User?,
    allPosts: List<BlogPost>,
    reportedPosts: List<BlogPost> = emptyList(),
    allUsers: List<User>,
    categories: List<Category>,
    pendingPosts: List<BlogPost> = emptyList(),
    totalComments: Int,
    adminWithdrawals: List<WithdrawalRequest> = emptyList(),
    allPurchases: List<ArticlePurchase> = emptyList(),
    allAdMetrics: List<AdMetric> = emptyList(),
    allAdCampaigns: List<AdCampaign> = emptyList(),
    pendingAdCampaigns: List<AdCampaign> = emptyList(),
    onToggleUserBan: (User) -> Unit,
    onAddCategory: (String, String) -> Unit,
    onDeleteCategory: (Long) -> Unit,
    onToggleFeatured: (Long, Boolean) -> Unit,
    onUpdatePostStatus: (Long, PostStatus) -> Unit = { _, _ -> },
    onDeletePost: (Long) -> Unit,
    onPostClick: (Long) -> Unit,
    onProcessWithdrawal: (requestId: Long, userId: Long, amount: Double, approve: Boolean, reason: String) -> Unit = { _, _, _, _, _ -> },
    onApproveAdCampaign: (Long) -> Unit = {},
    onRejectAdCampaign: (Long) -> Unit = {},
    onDeleteAdCampaign: (Long) -> Unit = {},
    onDismissPostReport: (Long) -> Unit = {}
) {
    var adminTab by remember { mutableIntStateOf(0) } // 0: إدارة المقالات والبلاغات, 1: مراجعة إعلانات المعلنين, 2: المستخدمين, 3: التصنيفات, 4: السحوبات والمالية
    var newCatName by remember { mutableStateOf("") }
    var newCatDesc by remember { mutableStateOf("") }
    var showAddCatDialog by remember { mutableStateOf(false) }
    var postToDeleteId by remember { mutableStateOf<Long?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_panel_screen"),
        contentPadding = PaddingValues(bottom = 96.dp, start = 16.dp, end = 16.dp, top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Admin Supervisor Header Badge
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = AdminPurple
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = GoldAccent,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "لوحة تحكم المشرف العام (ADMIN)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "صلاحيات فورية: حذف المقالات المخالفة واعتماد إعلانات المعلنين",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Metrics Grid Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricBadge("المقالات", "${allPosts.size}")
                        MetricBadge("البلاغات", "${reportedPosts.size}")
                        MetricBadge("إعلانات معلقة", "${pendingAdCampaigns.size}")
                        MetricBadge("المستخدمين", "${allUsers.size}")
                        MetricBadge("التعليقات", "$totalComments")
                    }
                }
            }
        }

        // Admin Sub-Tabs Navigation
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            ) {
                ScrollableTabRow(
                    selectedTabIndex = adminTab,
                    containerColor = Color.Transparent,
                    divider = {},
                    edgePadding = 8.dp
                ) {
                    Tab(selected = adminTab == 0, onClick = { adminTab = 0 }) {
                        val reportCount = reportedPosts.size
                        Text(
                            text = if (reportCount > 0) "المقالات والبلاغات ⚠️ ($reportCount)" else "المقالات (${allPosts.size})",
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp),
                            fontWeight = FontWeight.Bold,
                            color = if (reportCount > 0) MaterialTheme.colorScheme.error else Color.Unspecified
                        )
                    }
                    Tab(selected = adminTab == 1, onClick = { adminTab = 1 }) {
                        val pendingAds = pendingAdCampaigns.size
                        Text(
                            text = if (pendingAds > 0) "إعلانات المعلنين ⏳ ($pendingAds)" else "الإعلانات (${allAdCampaigns.size})",
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp),
                            fontWeight = FontWeight.Bold,
                            color = if (pendingAds > 0) GoldAccent else Color.Unspecified
                        )
                    }
                    Tab(selected = adminTab == 2, onClick = { adminTab = 2 }) {
                        Text("المستخدمين (${allUsers.size})", fontSize = 12.sp, modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold)
                    }
                    Tab(selected = adminTab == 3, onClick = { adminTab = 3 }) {
                        Text("التصنيفات (${categories.size})", fontSize = 11.sp, modifier = Modifier.padding(8.dp), fontWeight = FontWeight.Bold)
                    }
                    Tab(selected = adminTab == 4, onClick = { adminTab = 4 }) {
                        val pendingCount = adminWithdrawals.count { it.status == WithdrawalStatus.PENDING }
                        Text("السحوبات ($pendingCount)", fontSize = 11.sp, modifier = Modifier.padding(8.dp), fontWeight = FontWeight.Bold, color = if (pendingCount > 0) GoldAccent else Color.Unspecified)
                    }
                }
            }
        }

        // TAB 0: ARTICLES & REPORTED CONTENT MODERATION (FULL ADMIN CONTROL)
        if (adminTab == 0) {
            // Reported Posts Section (High Priority)
            if (reportedPosts.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "مقالات تم الإبلاغ عنها كمحتوى غير مناسب (${reportedPosts.size})",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                                )
                            }
                            Text(
                                text = "تنبيه للمشرف: يرجى مراجعة المقالات المبلغ عنها وحذف المخالف منها فوراً لضمان سلامة المحتوى.",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }

                items(reportedPosts) { post ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "🚨 بلاغ محتوى مخالف",
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                    )
                                }

                                TextButton(onClick = { onPostClick(post.id) }) {
                                    Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("معاينة المقال", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = post.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "بقلم: ${post.authorName} | التصنيف: ${post.categoryName}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )

                            if (post.reportReason.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Outlined.Flag, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "سبب البلاغ: ${post.reportReason}",
                                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { postToDeleteId = post.id },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("حذف المقال فوراً من المنصة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { onDismissPostReport(post.id) },
                                    modifier = Modifier.weight(0.7f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تجاهل وتثبيت", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "جميع منشورات ومقالات المنصة (${allPosts.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SuccessGreen.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "نشر فوري للمبدعين ⚡",
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            items(allPosts) { post ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (post.status == PostStatus.PUBLISHED) SuccessGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = if (post.status == PostStatus.PUBLISHED) "منشور ومتاح للقراء" else "مسودة خاصة",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { onToggleFeatured(post.id, post.isFeatured) }
                                ) {
                                    Icon(
                                        imageVector = if (post.isFeatured) Icons.Default.Star else Icons.Default.StarBorder,
                                        contentDescription = "مميز",
                                        tint = GoldAccent
                                    )
                                }
                                IconButton(
                                    onClick = { postToDeleteId = post.id }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف المقال",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = post.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "بقلم: ${post.authorName} | التصنيف: ${post.categoryName}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { onPostClick(post.id) }) {
                                Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("معاينة المقال", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { postToDeleteId = post.id },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.error),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("حذف المقال كإدارة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: ADVERTISER CAMPAIGNS & MODERATION (ADMIN-ONLY APPROVE / REJECT)
        if (adminTab == 1) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GoldAccent.copy(alpha = 0.15f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Campaign, contentDescription = null, tint = GoldAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "مراجعة واعتماد إعلانات المعلنين (Advertiser Ads)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Text(
                            text = "الإعلانات المرفوعة من حسابات المعلنين تدخل حالة الانتظار (PENDING). بصفتك المشرف العام، يمكنك الموافقة أو الرفض قبل ظهور الإعلان.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Pending Campaigns First
            item {
                Text(
                    text = "طلبات الإعلانات المعلقة بانتظار الموافقة (${pendingAdCampaigns.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (pendingAdCampaigns.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد حملات إعلانية معلقة حالياً.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(pendingAdCampaigns) { campaign ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "إعلان من: ${campaign.advertiserName.ifBlank { "حساب معلن #${campaign.advertiserId}" }}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = GoldAccent.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "قيد المراجعة ⏳",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldAccent
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(campaign.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)

                            if (campaign.bannerUrl.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                AsyncImage(
                                    model = campaign.bannerUrl,
                                    contentDescription = "بانر الإعلان",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                        .clip(RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("الرابط الموجه: ${campaign.targetUrl}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            Text("المكان: ${when(campaign.placement) { AdPlacement.HEADER -> "الهيدر"; AdPlacement.FOOTER -> "الفوتر"; AdPlacement.FEED_NATIVE -> "بين المقالات"; AdPlacement.IN_ARTICLE -> "داخل المقال" }} | الميزانية: $${String.format("%.2f", campaign.budget)} | سعر النقرة: $${campaign.costPerClick}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(12.dp))

                            // Admin Approve / Reject Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onApproveAdCampaign(campaign.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("قبول ونشر الإعلان", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { onRejectAdCampaign(campaign.id) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.weight(0.8f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رفض الإعلان", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // All Campaigns Section
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "كافة الحملات الإعلانية المسجلة (${allAdCampaigns.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            items(allAdCampaigns) { campaign ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(campaign.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (campaign.status) {
                                    CampaignStatus.ACTIVE -> SuccessGreen.copy(alpha = 0.2f)
                                    CampaignStatus.PENDING_APPROVAL -> GoldAccent.copy(alpha = 0.2f)
                                    CampaignStatus.PAUSED -> MaterialTheme.colorScheme.surfaceVariant
                                    CampaignStatus.REJECTED -> MaterialTheme.colorScheme.errorContainer
                                    CampaignStatus.COMPLETED -> MaterialTheme.colorScheme.primaryContainer
                                }
                            ) {
                                Text(
                                    text = when (campaign.status) {
                                        CampaignStatus.ACTIVE -> "نشطة 🟢"
                                        CampaignStatus.PENDING_APPROVAL -> "معلقة ⏳"
                                        CampaignStatus.PAUSED -> "متوقفة ⏸️"
                                        CampaignStatus.REJECTED -> "مرفوضة ❌"
                                        CampaignStatus.COMPLETED -> "مكتملة 🏁"
                                    },
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text("المعلن: ${campaign.advertiserName} | الميزانية: $${campaign.budget} | المستهلك: $${String.format("%.2f", campaign.spentAmount)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            IconButton(onClick = { onDeleteAdCampaign(campaign.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف الحملة", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // TAB 2: USER MANAGEMENT
        if (adminTab == 2) {
            item {
                Text(
                    text = "قائمة المستخدمين والكُتاب (${allUsers.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            items(allUsers) { user ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(40.dp),
                                shape = CircleShape,
                                color = if (user.role == UserRole.ADMIN) AdminPurple else MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (user.role == UserRole.ADMIN) Icons.Default.Security else Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color.White
                                    )
                                }
                            }

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = user.displayName,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    if (user.role == UserRole.ADMIN) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "(المشرف العام)",
                                            style = MaterialTheme.typography.labelSmall.copy(color = AdminPurple, fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                                Text(
                                    text = user.email,
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                                Text(
                                    text = "الدور: ${when(user.role) { UserRole.READER -> "قارئ"; UserRole.AUTHOR -> "كاتب"; UserRole.ADVERTISER -> "معلن"; UserRole.ADMIN -> "مشرف" }} | الهاتف: ${user.phoneNumber.ifBlank { "غير مسجل" }} (${if (user.isPhoneVerified) "موثق ✅" else "غير موثق ❌"}) | KYC: ${if (user.isKycVerified) "مقبول ✅" else "لم يوثق ❌"}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (user.role != UserRole.ADMIN) {
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = { onToggleUserBan(user) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (user.status == UserStatus.ACTIVE) MaterialTheme.colorScheme.error else SuccessGreen
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(if (user.status == UserStatus.ACTIVE) "حظر" else "إلغاء الحظر", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: CATEGORY MANAGEMENT
        if (adminTab == 3) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تصنيفات المدونة",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Button(
                        onClick = { showAddCatDialog = true },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة تصنيف")
                    }
                }
            }

            items(categories) { cat ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(cat.name, fontWeight = FontWeight.Bold)
                            if (cat.description.isNotBlank()) {
                                Text(cat.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        IconButton(onClick = { onDeleteCategory(cat.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }

        // TAB 4: WITHDRAWALS & FINANCIALS
        if (adminTab == 4) {
            val totalPlatformSalesComm = allPurchases.sumOf { it.platformShare }
            val totalPlatformAdComm = allAdMetrics.sumOf { it.platformShare }
            val pendingRequests = adminWithdrawals.filter { it.status == WithdrawalStatus.PENDING }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("الملخص المالي للمشرف العام والمنصة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("عمولة المنصة من المبيعات (20%)", style = MaterialTheme.typography.labelSmall)
                                Text("${String.format("%.2f", totalPlatformSalesComm)} $", fontWeight = FontWeight.Bold, color = SuccessGreen)
                            }
                            Column {
                                Text("حصة المنصة من الإعلانات (40%)", style = MaterialTheme.typography.labelSmall)
                                Text("${String.format("%.2f", totalPlatformAdComm)} $", fontWeight = FontWeight.Bold, color = GoldAccent)
                            }
                            Column {
                                Text("إجمالي دخل المنصة الصافي", style = MaterialTheme.typography.labelSmall)
                                Text("${String.format("%.2f", totalPlatformSalesComm + totalPlatformAdComm)} $", fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "طلبات السحب المعلقة (${pendingRequests.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (adminWithdrawals.isEmpty()) {
                item {
                    Text("لا توجد طلبات سحب في النظام حتى الآن.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(adminWithdrawals) { req ->
                    var showRejectDialog by remember { mutableStateOf(false) }
                    var rejectionReason by remember { mutableStateOf("") }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("طلب #${req.id} من: ${req.userName}", fontWeight = FontWeight.Bold)
                                Surface(
                                    color = when (req.status) {
                                        WithdrawalStatus.PENDING -> GoldAccent
                                        WithdrawalStatus.APPROVED -> SuccessGreen
                                        WithdrawalStatus.REJECTED -> MaterialTheme.colorScheme.error
                                    }.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = req.status.name,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text("البريد الإلكتروني: ${req.userEmail}", style = MaterialTheme.typography.bodySmall)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("المبلغ المطلوب: ${String.format("%.2f", req.amount)} $", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text("الصافي للتحويل: ${String.format("%.2f", req.netAmount)} $", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = SuccessGreen)
                            }
                            Text("رسوم التحويل والشبكة: ${String.format("%.2f", req.fee)} $ | وسيلة التحويل: ${req.payoutMethod}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("بيانات الحساب: ${req.accountDetails}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            if (req.status == WithdrawalStatus.PENDING) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            onProcessWithdrawal(req.id, req.userId, req.amount, true, "")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("موافقة وتحويل", fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { showRejectDialog = true },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("رفض ورد الرصيد", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    if (showRejectDialog) {
                        AlertDialog(
                            onDismissRequest = { showRejectDialog = false },
                            title = { Text("رفض طلب السحب وإعادة الرصيد") },
                            text = {
                                Column {
                                    Text("سيتم رفض طلب السحب بمبلغ ${req.amount} $ وإعادة المبلغ لرصيد الكاتب.")
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = rejectionReason,
                                        onValueChange = { rejectionReason = it },
                                        label = { Text("سبب الرفض") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        showRejectDialog = false
                                        onProcessWithdrawal(req.id, req.userId, req.amount, false, rejectionReason)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text("تأكيد الرفض")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showRejectDialog = false }) { Text("إلغاء") }
                            }
                        )
                    }
                }
            }
        }
    }

    // Direct Admin Delete Post Confirmation Dialog
    if (postToDeleteId != null) {
        AlertDialog(
            onDismissRequest = { postToDeleteId = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تأكيد حذف المقال من المنصة", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text("بصفتك المشرف العام، هل تريد حذف هذا المقال نهائياً من قاعدة البيانات وإزالته فوراً من كافة الأقسام والشاشات؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        postToDeleteId?.let { id ->
                            onDeletePost(id)
                        }
                        postToDeleteId = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف المقال فوراً")
                }
            },
            dismissButton = {
                TextButton(onClick = { postToDeleteId = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Add Category Dialog
    if (showAddCatDialog) {
        AlertDialog(
            onDismissRequest = { showAddCatDialog = false },
            title = { Text("إضافة تصنيف جديد") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = newCatName,
                        onValueChange = { newCatName = it },
                        label = { Text("اسم التصنيف") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newCatDesc,
                        onValueChange = { newCatDesc = it },
                        label = { Text("الوصف (اختياري)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newCatName.isNotBlank()) {
                            onAddCategory(newCatName, newCatDesc)
                            newCatName = ""
                            newCatDesc = ""
                            showAddCatDialog = false
                        }
                    }
                ) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCatDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun MetricBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 10.sp
            )
        )
    }
}
