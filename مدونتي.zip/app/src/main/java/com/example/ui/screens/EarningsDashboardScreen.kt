package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.SuccessGreen
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EarningsDashboardScreen(
    currentUser: User?,
    userWithdrawals: List<WithdrawalRequest>,
    authorSales: List<ArticlePurchase>,
    authorAdMetrics: List<AdMetric>,
    userAdCampaigns: List<AdCampaign> = emptyList(),
    onBackClick: () -> Unit,
    onNavigateToSupportTickets: () -> Unit = {},
    onTopUpWalletViaIap: (amount: Double, pkgName: String) -> Unit = { _, _ -> },
    onVerifyPhone: (phone: String) -> Unit = {},
    onSubmitKyc: (fullName: String, docId: String) -> Unit = { _, _ -> },
    onSubmitWithdrawal: (amount: Double, method: PayoutMethod, details: String) -> Unit,
    onSavePayoutSettings: (iban: String, swift: String, bankName: String, accountName: String, usdt: String, network: String, btc: String, eWalletType: String, eWalletAccount: String) -> Unit,
    onCreateAdCampaign: (title: String, bannerUrl: String, targetUrl: String, placement: AdPlacement, budget: Double, costPerClick: Double) -> Unit = { _, _, _, _, _, _ -> },
    onGenerateAdCopy: ((String, (String) -> Unit) -> Unit)? = null
) {
    if (currentUser == null) return

    var selectedTab by remember { mutableStateOf(0) } // 0: Overview, 1: Advertiser Campaigns, 2: Withdrawal Requests, 3: Payout Settings
    var showWithdrawalDialog by remember { mutableStateOf(false) }
    var showTopUpIapDialog by remember { mutableStateOf(false) }
    var showPhoneVerifyDialog by remember { mutableStateOf(false) }
    var showKycDialog by remember { mutableStateOf(false) }
    var showCreateCampaignDialog by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("ar")) }

    Scaffold(
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("لوحة أرباح الكاتب والمحفظة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToSupportTickets) {
                        Icon(Icons.Default.SupportAgent, contentDescription = "مركز الدعم والتذاكر")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Security & KYC Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (currentUser.isFraudFlagged) MaterialTheme.colorScheme.errorContainer
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("التحقق الأمني وتأكيد الهوية (KYC)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        TextButton(onClick = onNavigateToSupportTickets) {
                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تذاكر الدعم", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (currentUser.isFraudFlagged) {
                        Text(
                            text = "⚠️ الحساب معلق تحت مراجعة الأمان: ${currentUser.fraudReason.ifBlank { "نشاط غير عادي" }}",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Phone verify chip
                            AssistChip(
                                onClick = { showPhoneVerifyDialog = true },
                                modifier = Modifier.weight(1f),
                                label = { Text(if (currentUser.isPhoneVerified) "الهاتف موثق ✅" else "ربط الهاتف 📱", fontSize = 11.sp) },
                                leadingIcon = {
                                    Icon(
                                        if (currentUser.isPhoneVerified) Icons.Default.CheckCircle else Icons.Default.Phone,
                                        contentDescription = null,
                                        tint = if (currentUser.isPhoneVerified) SuccessGreen else MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )

                            // KYC verify chip
                            AssistChip(
                                onClick = { showKycDialog = true },
                                modifier = Modifier.weight(1f),
                                label = { Text(if (currentUser.isKycVerified) "الهوية موثقة ✅" else "توثيق الهوية 🆔", fontSize = 11.sp) },
                                leadingIcon = {
                                    Icon(
                                        if (currentUser.isKycVerified) Icons.Default.Badge else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (currentUser.isKycVerified) SuccessGreen else GoldAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // Header Balance Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "الرصيد المتاح للسحب",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.LightGray)
                                )
                                Text(
                                    text = "${String.format("%.2f", currentUser.balance)} $",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        color = GoldAccent,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                )
                                if (currentUser.pendingAdHoldBalance > 0) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Surface(
                                        color = Color(0xFFF59E0B).copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "🔒 ${String.format("%.2f", currentUser.pendingAdHoldBalance)} $ أرباح إعلانية معلقة (حجز 30 يوماً)",
                                            color = GoldAccent,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = { showTopUpIapDialog = true },
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                                ) {
                                    Icon(Icons.Default.AddCard, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("شحن IAP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { showWithdrawalDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("طلب سحب", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = Color.White.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("أرباح المقالات (65% صافي)", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                                Text(
                                    "${String.format("%.2f", currentUser.totalEarnedFromSales)} $",
                                    style = MaterialTheme.typography.titleSmall.copy(color = SuccessGreen, fontWeight = FontWeight.Bold)
                                )
                            }

                            Column {
                                Text("أرباح الإعلانات (25% eCPM)", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                                Text(
                                    "${String.format("%.2f", currentUser.totalEarnedFromAds)} $",
                                    style = MaterialTheme.typography.titleSmall.copy(color = GoldAccent, fontWeight = FontWeight.Bold)
                                )
                            }

                            Column {
                                Text("إجمالي الأرباح التراكمية", style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray))
                                Text(
                                    "${String.format("%.2f", currentUser.totalEarnedFromSales + currentUser.totalEarnedFromAds)} $",
                                    style = MaterialTheme.typography.titleSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }

            // Tabs Header
            ScrollableTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("المبيعات والإعلانات") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("حملاتي الإعلانية (${userAdCampaigns.size})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("سجل السحوبات (${userWithdrawals.size})") }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("وسائل السحب (IBAN/USDT/محافظ)") }
                )
            }

            // Tab Contents
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (selectedTab) {
                    0 -> EarningsOverviewTab(authorSales, authorAdMetrics, dateFormat)
                    1 -> AdvertiserCampaignsTab(
                        campaigns = userAdCampaigns,
                        dateFormat = dateFormat,
                        onCreateNewCampaign = { showCreateCampaignDialog = true }
                    )
                    2 -> WithdrawalHistoryTab(userWithdrawals, dateFormat)
                    3 -> PayoutSettingsTab(currentUser, onSavePayoutSettings)
                }
            }
        }
    }

    if (showCreateCampaignDialog) {
        CreateAdCampaignDialog(
            currentUser = currentUser,
            onDismiss = { showCreateCampaignDialog = false },
            onGenerateAdCopy = onGenerateAdCopy,
            onCreate = { title, bannerUrl, targetUrl, placement, budget, costPerClick ->
                showCreateCampaignDialog = false
                onCreateAdCampaign(title, bannerUrl, targetUrl, placement, budget, costPerClick)
            }
        )
    }

    if (showTopUpIapDialog) {
        GooglePlayIapTopUpDialog(
            onDismiss = { showTopUpIapDialog = false },
            onPackageSelected = { amount, title ->
                showTopUpIapDialog = false
                onTopUpWalletViaIap(amount, title)
            }
        )
    }

    if (showPhoneVerifyDialog) {
        PhoneVerificationDialog(
            currentPhone = currentUser.phoneNumber,
            onDismiss = { showPhoneVerifyDialog = false },
            onVerifySuccess = { phone ->
                showPhoneVerifyDialog = false
                onVerifyPhone(phone)
            }
        )
    }

    if (showKycDialog) {
        KycVerificationDialog(
            currentName = currentUser.kycFullName.ifBlank { currentUser.displayName },
            currentDocId = currentUser.kycDocumentId,
            onDismiss = { showKycDialog = false },
            onSubmitKyc = { name, doc ->
                showKycDialog = false
                onSubmitKyc(name, doc)
            }
        )
    }

    if (showWithdrawalDialog) {
        WithdrawalRequestDialog(
            currentUser = currentUser,
            onDismiss = { showWithdrawalDialog = false },
            onSubmit = { amount, method, details ->
                showWithdrawalDialog = false
                onSubmitWithdrawal(amount, method, details)
            }
        )
    }
}

@Composable
fun GooglePlayIapTopUpDialog(
    onDismiss: () -> Unit,
    onPackageSelected: (amount: Double, title: String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ShopTwo, contentDescription = null, tint = GoldAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text("شحن المحفظة (Google Play IAP)", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "اختر إحدى باقات الشحن المباشر عبر Google Play In-App Purchases:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                IapPackageItem("باقة الكاتب البرونزية", 4.99, "إضافة 5.00$ لرصيد المحفظة") { onPackageSelected(5.0, "باقة الكاتب البرونزية") }
                Spacer(modifier = Modifier.height(6.dp))
                IapPackageItem("باقة الكاتب الفضية", 9.99, "إضافة 10.00$ + مكافأة 1.00$") { onPackageSelected(11.0, "باقة الكاتب الفضية") }
                Spacer(modifier = Modifier.height(6.dp))
                IapPackageItem("باقة الكاتب الذهبية الممتازة", 19.99, "إضافة 20.00$ + مكافأة 3.00$") { onPackageSelected(23.0, "باقة الكاتب الذهبية") }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
private fun IapPackageItem(title: String, price: Double, description: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                color = GoldAccent,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("$price $", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PhoneVerificationDialog(
    currentPhone: String,
    onDismiss: () -> Unit,
    onVerifySuccess: (phone: String) -> Unit
) {
    var phoneInput by remember { mutableStateOf(currentPhone.ifBlank { "+966500000000" }) }
    var otpCode by remember { mutableStateOf("") }
    var isCodeSent by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تأكيد رقم الهاتف (SMS / OTP)", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("أدخل رقم الهاتف للتحقق ومنع إنشاء حسابات متكررة على نفس الجهاز.", fontSize = 12.sp)

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("رقم الهاتف الدولي") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (isCodeSent) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = otpCode,
                        onValueChange = { otpCode = it },
                        label = { Text("رمز التحقق OTP (أدخل 1234)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!isCodeSent) {
                        isCodeSent = true
                    } else {
                        onVerifySuccess(phoneInput)
                    }
                }
            ) {
                Text(if (!isCodeSent) "إرسال رمز OTP" else "تأكيد الكود وتفعيل الرقم")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun KycVerificationDialog(
    currentName: String,
    currentDocId: String,
    onDismiss: () -> Unit,
    onSubmitKyc: (fullName: String, docId: String) -> Unit
) {
    var nameInput by remember { mutableStateOf(currentName) }
    var docInput by remember { mutableStateOf(currentDocId) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("توثيق الهوية المالي (KYC)", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("يتطلب متجر Google Play والسياسات المالية تأكيد اسم الهوية ورقم الوثيقة الوطنية/الجواز قبل فتح السحوبات المالية.", fontSize = 12.sp)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("الاسم الكامل كما في الهوية الوطنية/الجواز") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = docInput,
                    onValueChange = { docInput = it },
                    label = { Text("رقم الهوية الوطنية / جواز السفر") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmitKyc(nameInput, docInput) },
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
            ) {
                Text("تأكيد وتوثيق الهوية", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
private fun EarningsOverviewTab(
    sales: List<ArticlePurchase>,
    adMetrics: List<AdMetric>,
    dateFormat: SimpleDateFormat
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "آخر مبيعات المقالات المدفوعة (حصة الكاتب الصافية 65%)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "يتم اقتطاع 15% لمتجر Google Play أولاً، ثم 20% عمولة المنصة، و65% صافي مباشر لرصيدك.",
                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            )
        }

        if (sales.isEmpty()) {
            item {
                Text(
                    text = "لا توجد مبيعات مقالات حتى الآن.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        } else {
            items(sales) { sale ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "مقال: ${sale.postTitle}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                text = "طريقة الشراء: ${sale.purchaseMethod} | ${dateFormat.format(Date(sale.purchasedAt))}",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Text(
                                text = "Google Play (15%): -${String.format("%.2f", sale.googlePlayFee)}$ | عمولة المنصة (20%): -${String.format("%.2f", sale.platformShare)}$",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 10.sp)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "+${String.format("%.2f", sale.authorShare)} $",
                                style = MaterialTheme.typography.titleSmall.copy(color = SuccessGreen, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "السعر: ${sale.priceAmount} $",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "آخر أرباح مشاركة الإعلانات (حصة الكاتب 25% - Real-time eCPM)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "تحسب الأرباح بعد استمرار القارئ 15 ثانية داخل المقال، وتخضع لحجز 30 يوماً لضمان التسوية.",
                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            )
        }

        if (adMetrics.isEmpty()) {
            item {
                Text(
                    text = "لا توجد مشاهدات إعلانات مسجلة حتى الآن.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        } else {
            items(adMetrics.take(20)) { metric ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "إعلان ${metric.adType} (${metric.adProvider})", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "eCPM: ${metric.ecpm}$ | ${dateFormat.format(Date(metric.createdAt))}",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "+${String.format("%.4f", metric.authorShare)} $",
                                style = MaterialTheme.typography.titleSmall.copy(color = GoldAccent, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "25% من العائد",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Color.Gray)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WithdrawalHistoryTab(
    requests: List<WithdrawalRequest>,
    dateFormat: SimpleDateFormat
) {
    if (requests.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(bottom = 96.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد طلبات سحب سابقة.")
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(requests) { req ->
            val statusColor = when (req.status) {
                WithdrawalStatus.PENDING -> GoldAccent
                WithdrawalStatus.APPROVED -> SuccessGreen
                WithdrawalStatus.REJECTED -> MaterialTheme.colorScheme.error
            }

            val statusText = when (req.status) {
                WithdrawalStatus.PENDING -> "قيد المراجعة"
                WithdrawalStatus.APPROVED -> "مقبول - تم التحويل"
                WithdrawalStatus.REJECTED -> "مرفوض"
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "طلب #${req.id} - ${req.payoutMethod}",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            color = statusColor.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "المبلغ المطلوب: ${String.format("%.2f", req.amount)} $",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "الصافي: ${String.format("%.2f", req.netAmount)} $ (رسوم: ${String.format("%.2f", req.fee)}$)",
                            style = MaterialTheme.typography.bodyMedium.copy(color = SuccessGreen, fontWeight = FontWeight.Bold)
                        )
                    }

                    Text(
                        text = "تفاصيل الحساب: ${req.accountDetails}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "التاريخ: ${dateFormat.format(Date(req.requestedAt))}",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )

                    if (req.status == WithdrawalStatus.REJECTED && req.rejectionReason.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "سبب الرفض: ${req.rejectionReason}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PayoutSettingsTab(
    currentUser: User,
    onSave: (iban: String, swift: String, bankName: String, accountName: String, usdt: String, network: String, btc: String, eWalletType: String, eWalletAccount: String) -> Unit
) {
    var iban by remember(currentUser) { mutableStateOf(currentUser.bankIban) }
    var swift by remember(currentUser) { mutableStateOf(currentUser.bankSwift) }
    var bankName by remember(currentUser) { mutableStateOf(currentUser.bankName) }
    var accountName by remember(currentUser) { mutableStateOf(currentUser.bankAccountName) }

    var usdtAddress by remember(currentUser) { mutableStateOf(currentUser.cryptoUsdtAddress) }
    var network by remember(currentUser) { mutableStateOf(currentUser.cryptoNetwork.ifBlank { "TRC20" }) }
    var btcAddress by remember(currentUser) { mutableStateOf(currentUser.cryptoBtcAddress) }

    var eWalletType by remember(currentUser) { mutableStateOf(currentUser.eWalletType.ifBlank { "PayPal" }) }
    var eWalletAccount by remember(currentUser) { mutableStateOf(currentUser.eWalletAccount) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Bank Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalance, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "1. الحساب البنكي (Bank Account)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = bankName,
                        onValueChange = { bankName = it },
                        label = { Text("اسم البنك (Bank Name)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = accountName,
                        onValueChange = { accountName = it },
                        label = { Text("اسم صاحب الحساب الثلاثي") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = iban,
                        onValueChange = { iban = it },
                        label = { Text("رقم الآيبان (IBAN)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = swift,
                        onValueChange = { swift = it },
                        label = { Text("رمز السويفت (SWIFT / BIC)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Crypto Wallets Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CurrencyBitcoin, contentDescription = null, tint = GoldAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "2. العملات الرقمية (Crypto Wallets)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = usdtAddress,
                        onValueChange = { usdtAddress = it },
                        label = { Text("عنوان محفظة USDT") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = network,
                        onValueChange = { network = it },
                        label = { Text("شبكة USDT (TRC20 / BEP20 / ERC20)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = btcAddress,
                        onValueChange = { btcAddress = it },
                        label = { Text("عنوان محفظة البيتكوين (Bitcoin BTC)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // E-Wallets Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Payment, contentDescription = null, tint = SuccessGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "3. المحافظ الإلكترونية (E-Wallets)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("اختر نوع المحفظة الإلكترونية:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = eWalletType == "PayPal",
                            onClick = { eWalletType = "PayPal" },
                            label = { Text("PayPal") }
                        )
                        FilterChip(
                            selected = eWalletType == "Vodafone Cash",
                            onClick = { eWalletType = "Vodafone Cash" },
                            label = { Text("فودافون كاش") }
                        )
                        FilterChip(
                            selected = eWalletType == "STC Pay",
                            onClick = { eWalletType = "STC Pay" },
                            label = { Text("STC Pay") }
                        )
                        FilterChip(
                            selected = eWalletType == "أخرى",
                            onClick = { eWalletType = "أخرى" },
                            label = { Text("أخرى") }
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = eWalletAccount,
                        onValueChange = { eWalletAccount = it },
                        label = { Text("حساب المحفظة (البريد الإلكتروني / رقم الجوال)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Save Button
        item {
            Button(
                onClick = {
                    onSave(iban, swift, bankName, accountName, usdtAddress, network, btcAddress, eWalletType, eWalletAccount)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("حفظ كافة بيانات وسائل السحب", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun WithdrawalRequestDialog(
    currentUser: User,
    onDismiss: () -> Unit,
    onSubmit: (amount: Double, method: PayoutMethod, details: String) -> Unit
) {
    var amountInput by remember { mutableStateOf("50.0") }
    var selectedMethod by remember { mutableStateOf(PayoutMethod.BANK) }

    var detailsText by remember(selectedMethod, currentUser) {
        mutableStateOf(
            when (selectedMethod) {
                PayoutMethod.BANK -> "البنك: ${currentUser.bankName} | الاسم: ${currentUser.bankAccountName} | IBAN: ${currentUser.bankIban}"
                PayoutMethod.USDT -> "USDT (${currentUser.cryptoNetwork}): ${currentUser.cryptoUsdtAddress}"
                PayoutMethod.BTC -> "BTC: ${currentUser.cryptoBtcAddress}"
                PayoutMethod.E_WALLET -> "${currentUser.eWalletType}: ${currentUser.eWalletAccount}"
            }
        )
    }

    val parsedAmount = amountInput.toDoubleOrNull() ?: 0.0
    val withdrawalFee = when (selectedMethod) {
        PayoutMethod.BANK -> 5.00
        PayoutMethod.USDT -> 1.50
        PayoutMethod.BTC -> 3.00
        PayoutMethod.E_WALLET -> 0.75
    }
    val netPayout = (parsedAmount - withdrawalFee).coerceAtLeast(0.0)
    val isAmountValid = parsedAmount >= 50.0 && parsedAmount <= currentUser.balance
    val canWithdraw = currentUser.isPhoneVerified && currentUser.isKycVerified && !currentUser.isFraudFlagged && isAmountValid

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تقديم طلب سحب أرباح", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (!currentUser.isPhoneVerified || !currentUser.isKycVerified || currentUser.isFraudFlagged) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "⚠️ يلزم توثيق الهوية (KYC) ورقم الهاتف وتأكيد سلامة الحساب قبل تقديم طلبات السحب.",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(10.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                Text(
                    text = "رصيدك المتاح للسحب حالياً: ${String.format("%.2f", currentUser.balance)} $",
                    style = MaterialTheme.typography.bodyMedium.copy(color = GoldAccent, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "ملاحظة: الحد الأدنى لطلب السحب هو 50 دولار / USDT",
                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("المبلغ المراد سحبه ($)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    isError = parsedAmount < 50.0 || parsedAmount > currentUser.balance
                )
                if (parsedAmount < 50.0 && amountInput.isNotBlank()) {
                    Text("الحد الأدنى للسحب هو 50$", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                } else if (parsedAmount > currentUser.balance) {
                    Text("المبلغ المطلوب أكبر من رصيدك المتاح", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("وسيلة السحب المطلوب التحويل إليها:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedMethod == PayoutMethod.BANK,
                        onClick = { selectedMethod = PayoutMethod.BANK },
                        label = { Text("بنكي ($5)", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedMethod == PayoutMethod.USDT,
                        onClick = { selectedMethod = PayoutMethod.USDT },
                        label = { Text("USDT ($1.5)", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedMethod == PayoutMethod.BTC,
                        onClick = { selectedMethod = PayoutMethod.BTC },
                        label = { Text("BTC ($3)", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedMethod == PayoutMethod.E_WALLET,
                        onClick = { selectedMethod = PayoutMethod.E_WALLET },
                        label = { Text("محفظة ($0.75)", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Breakdown summary card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("المبلغ المطلوب:", fontSize = 11.sp)
                            Text("${String.format("%.2f", parsedAmount)} $", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("رسوم التحويل والشبكة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                            Text("-${String.format("%.2f", withdrawalFee)} $", fontSize = 11.sp, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.padding(vertical = 4.dp), color = Color.Gray.copy(alpha = 0.2f))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("صافي المبلغ المحول:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("${String.format("%.2f", netPayout)} $", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = SuccessGreen)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = detailsText,
                    onValueChange = { detailsText = it },
                    label = { Text("تفاصيل الحساب أو المحفظة") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountInput.toDoubleOrNull() ?: 0.0
                    onSubmit(amount, selectedMethod, detailsText)
                },
                enabled = canWithdraw,
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
            ) {
                Text("إرسال طلب السحب", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AdvertiserCampaignsTab(
    campaigns: List<AdCampaign>,
    dateFormat: SimpleDateFormat,
    onCreateNewCampaign: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("الحملات الإعلانية المباشرة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("إدارة حملاتك المباشرة وتتبع النقرات والميزانية المستهلكة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onCreateNewCampaign,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("إطلاق حملة", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (campaigns.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(bottom = 96.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("لا توجد حملات إعلانية حالية.", fontWeight = FontWeight.Bold)
                    Text("قم بشحن محفظتك وإطلاق حملتك الإعلانية الأولى لعرض بنراتك على جميع القراء.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(campaigns) { campaign ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(campaign.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = when (campaign.status) {
                                        CampaignStatus.ACTIVE -> SuccessGreen.copy(alpha = 0.2f)
                                        CampaignStatus.PENDING_APPROVAL -> GoldAccent.copy(alpha = 0.2f)
                                        CampaignStatus.PAUSED -> MaterialTheme.colorScheme.surfaceVariant
                                        CampaignStatus.REJECTED -> MaterialTheme.colorScheme.errorContainer
                                        CampaignStatus.COMPLETED -> MaterialTheme.colorScheme.primaryContainer
                                    }
                                ) {
                                    Text(
                                        text = when (campaign.status) {
                                            CampaignStatus.ACTIVE -> "نشطة ومعتمدة 🟢"
                                            CampaignStatus.PENDING_APPROVAL -> "بانتظار موافقة الإدارة ⏳"
                                            CampaignStatus.PAUSED -> "متوقفة مؤقتاً ⏸️"
                                            CampaignStatus.REJECTED -> "مرفوضة من الإدارة ❌"
                                            CampaignStatus.COMPLETED -> "مكتملة 🏁"
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (campaign.status) {
                                            CampaignStatus.ACTIVE -> SuccessGreen
                                            CampaignStatus.PENDING_APPROVAL -> GoldAccent
                                            CampaignStatus.PAUSED -> MaterialTheme.colorScheme.onSurfaceVariant
                                            CampaignStatus.REJECTED -> MaterialTheme.colorScheme.error
                                            CampaignStatus.COMPLETED -> MaterialTheme.colorScheme.primary
                                        }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("مكان العرض: ${when(campaign.placement) { AdPlacement.HEADER -> "الهيدر (أسفل البحث)"; AdPlacement.FOOTER -> "الفوتر (أسفل الشاشة)"; AdPlacement.FEED_NATIVE -> "بين المقالات (Native)"; AdPlacement.IN_ARTICLE -> "داخل المقال" }}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("سعر النقرة: $${campaign.costPerClick}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("المشاهدات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${campaign.impressionsCount}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("النقرات", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${campaign.clicksCount}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("الميزانية", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("$${String.format("%.2f", campaign.budget)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("المستهلك", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("$${String.format("%.2f", campaign.spentAmount)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateAdCampaignDialog(
    currentUser: User,
    onDismiss: () -> Unit,
    onGenerateAdCopy: ((String, (String) -> Unit) -> Unit)? = null,
    onCreate: (title: String, bannerUrl: String, targetUrl: String, placement: AdPlacement, budget: Double, costPerClick: Double) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var bannerUrl by remember { mutableStateOf("") }
    var targetUrl by remember { mutableStateOf("") }
    var selectedPlacement by remember { mutableStateOf(AdPlacement.IN_ARTICLE) }
    var budgetInput by remember { mutableStateOf("25.0") }
    var cpcInput by remember { mutableStateOf("0.25") }
    var isGeneratingCopy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إطلاق حملة إعلانية جديدة", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("رصيد محفظتك المتاح لتمويل الحملة: $${String.format("%.2f", currentUser.balance)}", fontSize = 12.sp, color = GoldAccent, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                // AI Ad Copy Assistant Button
                if (onGenerateAdCopy != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("مساعد الصياغة الإعلانية AI", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Button(
                                onClick = {
                                    val topic = title.ifBlank { "خدمة أو منتج مميز عبر الإنترنت" }
                                    isGeneratingCopy = true
                                    onGenerateAdCopy(topic) { result ->
                                        isGeneratingCopy = false
                                        title = result.lines().firstOrNull()?.replace("^[0-9•\\.\\-\\s]+".toRegex(), "") ?: result.take(50)
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                enabled = !isGeneratingCopy
                            ) {
                                if (isGeneratingCopy) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("توليد...", fontSize = 10.sp)
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("توليد نص إعلاني ذكي", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان الإعلان / اسم الحملة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = targetUrl,
                    onValueChange = { targetUrl = it },
                    label = { Text("رابط الموقع أو التطبيق (Target URL)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = bannerUrl,
                    onValueChange = { bannerUrl = it },
                    label = { Text("رابط صورة البنر الإعلاني (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Text("مكان عرض الإعلان:", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = selectedPlacement == AdPlacement.HEADER,
                        onClick = { selectedPlacement = AdPlacement.HEADER },
                        label = { Text("هيدر", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedPlacement == AdPlacement.IN_ARTICLE,
                        onClick = { selectedPlacement = AdPlacement.IN_ARTICLE },
                        label = { Text("داخل المقال", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedPlacement == AdPlacement.FEED_NATIVE,
                        onClick = { selectedPlacement = AdPlacement.FEED_NATIVE },
                        label = { Text("Native Feed", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedPlacement == AdPlacement.FOOTER,
                        onClick = { selectedPlacement = AdPlacement.FOOTER },
                        label = { Text("فوتر", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = budgetInput,
                        onValueChange = { budgetInput = it },
                        label = { Text("الميزانية ($)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = cpcInput,
                        onValueChange = { cpcInput = it },
                        label = { Text("سعر النقرة ($)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val budget = budgetInput.toDoubleOrNull() ?: 25.0
                    val cpc = cpcInput.toDoubleOrNull() ?: 0.25
                    onCreate(title, bannerUrl, targetUrl, selectedPlacement, budget, cpc)
                },
                enabled = title.isNotBlank() && targetUrl.isNotBlank()
            ) {
                Text("تمويل وإطلاق الحملة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
