package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SupportTicket
import com.example.data.model.TicketCategory
import com.example.data.model.TicketStatus
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.SuccessGreen
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SupportTicketsScreen(
    currentUser: User?,
    tickets: List<SupportTicket>,
    onBackClick: () -> Unit,
    onCreateTicket: (subject: String, category: TicketCategory, message: String) -> Unit,
    onReplyTicket: (ticketId: Long, reply: String, newStatus: TicketStatus) -> Unit
) {
    if (currentUser == null) return

    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedTicketForReply by remember { mutableStateOf<SupportTicket?>(null) }
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("ar")) }

    Scaffold(
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text("مركز الدعم الفني وتذاكر السحب", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("فتح تذكرة جديدة", fontWeight = FontWeight.Bold) },
                containerColor = GoldAccent,
                contentColor = Color.Black
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = if (currentUser.role == UserRole.ADMIN) "جميع تذاكر الدعم الفني الخاصة بالمستخدمين" else "تذاكر الدعم والتحقق الخاصة بك",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (tickets.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("لا توجد تذاكر دعم حالياً.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(tickets) { ticket ->
                        val statusColor = when (ticket.status) {
                            TicketStatus.OPEN -> GoldAccent
                            TicketStatus.IN_PROGRESS -> MaterialTheme.colorScheme.tertiary
                            TicketStatus.RESOLVED -> SuccessGreen
                            TicketStatus.CLOSED -> MaterialTheme.colorScheme.outline
                        }

                        val statusText = when (ticket.status) {
                            TicketStatus.OPEN -> "قيد المراجعة"
                            TicketStatus.IN_PROGRESS -> "جاري المعالجة"
                            TicketStatus.RESOLVED -> "تم الرد والحل ✅"
                            TicketStatus.CLOSED -> "مغلقة"
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "تذكرة #${ticket.id} - ${ticket.userName}",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Surface(
                                        color = statusColor.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = statusText,
                                            style = MaterialTheme.typography.labelSmall.copy(color = statusColor, fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(text = ticket.subject, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = ticket.message, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "التاريخ: ${dateFormat.format(Date(ticket.createdAt))}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (ticket.adminReply.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.SupportAgent, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("رد الدعم الفني:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(text = ticket.adminReply, fontSize = 12.sp)
                                        }
                                    }
                                }

                                if (currentUser.role == UserRole.ADMIN) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = { selectedTicketForReply = ticket },
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Icon(Icons.Default.Reply, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("الرد على التذكرة", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateSupportTicketDialog(
            onDismiss = { showCreateDialog = false },
            onSubmit = { subject, category, message ->
                showCreateDialog = false
                onCreateTicket(subject, category, message)
            }
        )
    }

    if (selectedTicketForReply != null) {
        ReplySupportTicketDialog(
            ticket = selectedTicketForReply!!,
            onDismiss = { selectedTicketForReply = null },
            onSubmitReply = { reply, newStatus ->
                val id = selectedTicketForReply!!.id
                selectedTicketForReply = null
                onReplyTicket(id, reply, newStatus)
            }
        )
    }
}

@Composable
fun CreateSupportTicketDialog(
    onDismiss: () -> Unit,
    onSubmit: (subject: String, category: TicketCategory, message: String) -> Unit
) {
    var subjectInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(TicketCategory.WITHDRAWAL) }
    var messageInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("فتح تذكرة دعم جديدة", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("قسم التذكرة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedCategory == TicketCategory.WITHDRAWAL,
                        onClick = { selectedCategory = TicketCategory.WITHDRAWAL },
                        label = { Text("السحب والأرباح", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = selectedCategory == TicketCategory.PAYWALL_IAP,
                        onClick = { selectedCategory = TicketCategory.PAYWALL_IAP },
                        label = { Text("الشراء IAP", fontSize = 10.sp) }
                    )
                    FilterChip(
                        selected = selectedCategory == TicketCategory.TECHNICAL,
                        onClick = { selectedCategory = TicketCategory.TECHNICAL },
                        label = { Text("تقني", fontSize = 10.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = subjectInput,
                    onValueChange = { subjectInput = it },
                    label = { Text("عنوان التذكرة") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = messageInput,
                    onValueChange = { messageInput = it },
                    label = { Text("تفاصيل الاستفسار أو المشكلة") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subjectInput.isNotBlank() && messageInput.isNotBlank()) {
                        onSubmit(subjectInput, selectedCategory, messageInput)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
            ) {
                Text("إرسال التذكرة", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun ReplySupportTicketDialog(
    ticket: SupportTicket,
    onDismiss: () -> Unit,
    onSubmitReply: (reply: String, newStatus: TicketStatus) -> Unit
) {
    var replyInput by remember { mutableStateOf(ticket.adminReply) }
    var selectedStatus by remember { mutableStateOf(TicketStatus.RESOLVED) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الرد على تذكرة #${ticket.id}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("المستخدم: ${ticket.userName}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("الموضوع: ${ticket.subject}", fontSize = 12.sp)
                Text("الرسالة: ${ticket.message}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = replyInput,
                    onValueChange = { replyInput = it },
                    label = { Text("نص الرد من الإدارة") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("حالة التذكرة بعد الرد:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedStatus == TicketStatus.RESOLVED,
                        onClick = { selectedStatus = TicketStatus.RESOLVED },
                        label = { Text("تم الحل ✅") }
                    )
                    FilterChip(
                        selected = selectedStatus == TicketStatus.CLOSED,
                        onClick = { selectedStatus = TicketStatus.CLOSED },
                        label = { Text("إغلاق التذكرة ❌") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (replyInput.isNotBlank()) {
                        onSubmitReply(replyInput, selectedStatus)
                    }
                }
            ) {
                Text("إرسال الرد وتحديث الحالة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
